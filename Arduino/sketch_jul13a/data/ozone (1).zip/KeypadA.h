/**
  ******************************************************************************
  * @file 		KeypadA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_KEYPAD_A
#define __INNO_KEYPAD_A	   
#include "innotype.h"
class KeypadA
{
    private:
	uint8_t SlaveID;
	public:
	KeypadA(uint8_t);
	void ClearKeyBuffer(void);
	uint8_t GetKeyID(uint8_t&);
	void SetKeypadMode(uint8_t);
	void GetKeypadMode(uint8_t&);
    

	void SetCustomTable(uint8_t *);
	void GetCustomTable(uint8_t *);
	void LoadCustomTable(uint8_t);
	void SaveCustomTable(uint8_t);
	void SetRepeatTime(uint8_t);
	void GetRepeatTime(uint8_t&);
	void SetRepeatRate(uint8_t);
	void GetRepeatRate(uint8_t&);
	void SetDebounceTime(uint8_t);
	void GetDebounceTime(uint8_t&);
	void GetCustomTableIndex(uint8_t&);
    
};
#endif



