/**
  ******************************************************************************
  * @file 		SonarA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "SonarA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
SonarA::SonarA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void SonarA::SetFloorLevel(uint8_t FloorLevel)
{
  __innoCommandBuff__[0] = 114;
  __innoCommandBuff__[2] = FloorLevel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarA::Ranging(void)
{
  __innoCommandBuff__[0] = 88;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void SonarA::RepeatRanging(void)
{
  __innoCommandBuff__[0] = 89;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void SonarA::StopRanging(void)
{
  __innoCommandBuff__[0] = 90;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t SonarA::GetDistance(uint8_t Type, uint16_t &Distance)
{
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Type;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
  	Distance  = *((uint16_t *)&__innoCommandBuff__[1]);
    return __innoCommandBuff__[0];
  }
  return 0;
}

void SonarA::SetRangingTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarA::GetRangingTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	 
}
void SonarA::SetBurstPower(uint8_t Power)
{
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = Power;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarA::GetBurstPower(uint8_t& Power)
{
  __innoCommandBuff__[0] = 94;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Power = __innoCommandBuff__[0];
  }	 
}
void SonarA::SetRepeatCount(uint8_t Count)
{
  __innoCommandBuff__[0] = 110;
  __innoCommandBuff__[2] = Count;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarA::SetRepeatTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 111;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarA::GetRepeatCount(uint8_t& Count)
{
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Count = __innoCommandBuff__[0];
  }	 
}
void SonarA::GetRepeatTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	 
}
void SonarA::GetFloorLevel(uint8_t& Level)
{
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Level = __innoCommandBuff__[0];
  }	 
}



