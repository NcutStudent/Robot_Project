/**
  ******************************************************************************
  * @file 		CompassA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *                                                                                                                                                                                                                                                                                                                                             
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_COMPASS_A
#define __INNO_COMPASS_A     
#include "innotype.h"
class CompassA
{
  private:
  uint8_t SlaveID;                                 
  public:
  CompassA(uint8_t); 
  void GetXYField(int16_t&, int16_t&);                                                                                                                                                                                                                                           
  void GetAngle(uint16_t&);
  void SaveAngle(uint8_t, uint16_t);                                                                                                                                                                                                                                                             
  void GetDevAngle(uint8_t, int16_t&);
  void GetHxHyHz(int16_t&, int16_t&, int16_t&);
  void SetRefreshFreq(uint8_t);
  uint8_t GetRefreshStatus(void);
  void Calibration(uint8_t);
  
  void GetXField(int16_t&);
  void GetYField(int16_t&);
  void GetField(uint16_t&, uint16_t&);
  void SaveCurrAngle(uint8_t);
  void LoadAngle(uint8_t, uint16_t&);
  void SetDevAngleLimit(uint8_t);
  void GetDevAngleLimit(uint8_t&);
  void SetDevAngleNum(uint8_t);
  void GetDevAngleNum(uint8_t&);
  uint8_t GetDevAngleLimitStatus(void);
  void GetRefreshFreq(uint8_t&);
  void SaveDefaultCalValue(void);
  void GetCalValue(int16_t&, int16_t&);
  void LoadDefaultCalValue(void);
  
};
#endif



