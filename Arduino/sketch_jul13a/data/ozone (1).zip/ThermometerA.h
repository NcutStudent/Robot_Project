/**
  ******************************************************************************
  * @file 		ThermometerA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_THERMOMETER_A
#define __INNO_THERMOMETER_A
#include "innotype.h"	 
class ThermometerA
{
    private:
	unsigned char SlaveID;
	public:
	ThermometerA(uint8_t);
	void GetTemp10F(int16_t &);
	void GetHumi10(uint16_t &);
	void GetDewpoint10F(int16_t &);
    
	void GetTempF(float&);
	void GetHumi(float&);
	void GetDewpointF(float&);
	uint8_t GetHeaterStatus(void);
	void SetHeaterStatus(uint8_t);
	void SetRecordTempCnt(uint16_t);
	void SetRecordHumiCnt(uint16_t);
	void SetRecordDewCnt(uint16_t);
	void StartAutoTempRecord(void);
	void StartAutoHumiRecord(void);
	void StartAutoDewRecord(void);
	void StopAutoTempRecord(uint8_t&, uint8_t&);
	void StopAutoHumiRecord(uint8_t&, uint8_t&);
	void StopAutoDewRecord(uint8_t&, uint8_t&);
	void GetSaveTemp10F(uint8_t, int16_t&);
	void GetSaveTempF(uint8_t, float&);
	void GetSaveHumi10(uint8_t, uint16_t&);
	void GetSaveHumi(uint8_t, float&);
	void GetSaveDew10F(uint8_t, int16_t&);
	void GetSaveDewF(uint8_t, float&);
	uint8_t GetTempAlarmStatus(void);
	uint8_t GetHumiAlarmStatus(void);
	uint8_t GetDewReachStatus(void);
	void GetRecordTempCnt(uint16_t&);
	void GetRecordHumiCnt(uint16_t&);
	void GetRecordDewCnt(uint16_t&);
	uint8_t GetRefreshStatus(void);

};
#endif



