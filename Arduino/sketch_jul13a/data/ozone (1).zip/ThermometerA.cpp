/**
  ******************************************************************************
  * @file 		ThermometerA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "ThermometerA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
ThermometerA::ThermometerA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void ThermometerA::GetTemp10F(int16_t &TempF)
{
  __innoCommandBuff__[0] = 88;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	TempF = *((int16_t *)&__innoCommandBuff__[0]);  
}
void ThermometerA::GetHumi10(uint16_t &Humi)
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Humi = *((uint16_t *)&__innoCommandBuff__[0]);	  
}
void ThermometerA::GetDewpoint10F(int16_t &Dewpoint)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 3;              
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Dewpoint = *((int16_t *)&__innoCommandBuff__[0]);
}					  


void ThermometerA::GetTempF(float& TempF)
{  
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  TempF = *((float *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetHumi(float& Hum)
{  
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Hum = *((float *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetDewpointF(float& DewpointF)
{  
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DewpointF = *((float *)&__innoCommandBuff__);   
  }	        
}

uint8_t ThermometerA::GetHeaterStatus(void)
{  
  __innoCommandBuff__[0] = 94;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;    
}

void ThermometerA::SetHeaterStatus(uint8_t Status)
{        
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Status;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

void ThermometerA::SetRecordTempCnt(uint16_t Cnt)
{          
  __innoCommandBuff__[0] = 106;
  *((uint16_t *)&__innoCommandBuff__[2]) = Cnt;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}

void ThermometerA::SetRecordHumiCnt(uint16_t Cnt)
{         
  __innoCommandBuff__[0] = 107;
  *((uint16_t *)&__innoCommandBuff__[2]) = Cnt;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}

void ThermometerA::SetRecordDewCnt(uint16_t Cnt)
{         
  __innoCommandBuff__[0] = 108;
  *((uint16_t *)&__innoCommandBuff__[2]) = Cnt;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}

void ThermometerA::StartAutoTempRecord(void)
{          
  __innoCommandBuff__[0] = 109;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}

void ThermometerA::StartAutoHumiRecord(void)
{   
  __innoCommandBuff__[0] = 110;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}

void ThermometerA::StartAutoDewRecord(void)
{  
  __innoCommandBuff__[0] = 111;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}

void ThermometerA::StopAutoTempRecord(uint8_t& Cnt, uint8_t& Over)
{  
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = __innoCommandBuff__[0];   
	  Over = __innoCommandBuff__[1];
  }	        
}

void ThermometerA::StopAutoHumiRecord(uint8_t& Cnt, uint8_t& Over)
{  
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = __innoCommandBuff__[0];   
	  Over = __innoCommandBuff__[1];
  }	 
}

void ThermometerA::StopAutoDewRecord(uint8_t& Cnt, uint8_t& Over)
{  
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = __innoCommandBuff__[0];   
	  Over = __innoCommandBuff__[1];
  }
}


void ThermometerA::GetSaveTemp10F(uint8_t Num, int16_t& Temp10F)
{  
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = Num;    
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Temp10F = *((int16_t *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetSaveTempF(uint8_t Num, float& TempF)
{  
  __innoCommandBuff__[0] = 119;
  __innoCommandBuff__[2] = Num;      
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  TempF = *((float *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetSaveHumi10(uint8_t Num, uint16_t& Humi10)
{  
  __innoCommandBuff__[0] = 120;
  __innoCommandBuff__[2] = Num;      
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Humi10 = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetSaveHumi(uint8_t Num, float& Humi)
{  
  __innoCommandBuff__[0] = 121;
  __innoCommandBuff__[2] = Num;   
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Humi = *((float *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetSaveDew10F(uint8_t Num, int16_t& Dew10F)
{  
  __innoCommandBuff__[0] = 122;
  __innoCommandBuff__[2] = Num;      
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Dew10F = *((int16_t *)&__innoCommandBuff__);  
  }	        
}

void ThermometerA::GetSaveDewF(uint8_t Num, float& DewF)
{  
  __innoCommandBuff__[0] = 123;
  __innoCommandBuff__[2] = Num;   
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  DewF = *((float *)&__innoCommandBuff__);   
  }	        
}
uint8_t ThermometerA::GetTempAlarmStatus(void)
{  
  __innoCommandBuff__[0] = 146;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	 
  return 0;  
}

uint8_t ThermometerA::GetHumiAlarmStatus(void)
{  
  __innoCommandBuff__[0] = 147;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;  
}

uint8_t ThermometerA::GetDewReachStatus(void)
{  
  __innoCommandBuff__[0] = 148;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	 
  return 0;  
}

void ThermometerA::GetRecordTempCnt(uint16_t& Cnt)
{  
  __innoCommandBuff__[0] = 149;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = *((uint16_t *)&__innoCommandBuff__);   
  }	        

}

void ThermometerA::GetRecordHumiCnt(uint16_t& Cnt)
{  
  __innoCommandBuff__[0] = 150;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}

void ThermometerA::GetRecordDewCnt(uint16_t& Cnt)
{  
  __innoCommandBuff__[0] = 151;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}

uint8_t ThermometerA::GetRefreshStatus(void)
{  
  __innoCommandBuff__[0] = 152;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;  
}



