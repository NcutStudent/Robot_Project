/**
  ******************************************************************************
  * @file 		ServoRunnerA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_SERVO_RUNNER_8
#define __INNO_SERVO_RUNNER_8
#include "innotype.h"
class ServoRunner8
{
    private:
	uint8_t SlaveID;
	public:
	ServoRunner8(uint8_t);
	void SetPosAndRun(uint8_t, uint16_t);
	void SetPosSpdAndRun(uint8_t, uint16_t, uint16_t);
	void SetPosTimeAndRun(uint8_t, uint16_t, uint16_t);
	void SetPos(uint8_t, uint16_t);
	void SetPosSpd(uint8_t, uint16_t, uint16_t);
	void SetPosTime(uint8_t, uint16_t, uint16_t);
	void Run1Servo(uint8_t);
	void Run2Servo(uint8_t, uint8_t);
	void Run3Servo(uint8_t, uint8_t, uint8_t);
	void Run4Servo(uint8_t, uint8_t, uint8_t, uint8_t);
	void Run5Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void Run6Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void Run7Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void RunAllServo(void);
	void Pause1Servo(uint8_t);
	void Pause2Servo(uint8_t, uint8_t);
	void Pause3Servo(uint8_t, uint8_t, uint8_t);
	void Pause4Servo(uint8_t, uint8_t, uint8_t, uint8_t);
	void Pause5Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void Pause6Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void Pause7Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);

	void PauseAllServo(void);
	void Stop1Servo(uint8_t);
	void Stop2Servo(uint8_t, uint8_t);
	void Stop3Servo(uint8_t, uint8_t, uint8_t);
	void Stop4Servo(uint8_t, uint8_t, uint8_t, uint8_t);
	void Stop5Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void Stop6Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void Stop7Servo(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void StopAllServo(void);
	void SetPosOffset(uint8_t, int8_t);    



	void Get1ServoReadyStatus(uint8_t, uint8_t&);
	void Get2ServoReadyStatus(uint8_t, uint8_t, uint8_t&);
	void Get3ServoReadyStatus(uint8_t, uint8_t, uint8_t, uint8_t&);
	void Get4ServoReadyStatus(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t&);
	void Get5ServoReadyStatus(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t&);
	void Get6ServoReadyStatus(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t&);
	void Get7ServoReadyStatus(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t&);
	void GetAllServoReadyStatus(uint8_t&);
	void GetNowPos(uint8_t, uint16_t&);
	void GetPos(uint8_t, uint16_t&);
	void GetSpdAndTime(uint8_t, uint8_t&, uint16_t&);
	void GetPosOffset(uint8_t, uint8_t&);
};
#endif



