/**
  ******************************************************************************
  * @file 		LCD4X20A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "LCD4X20A.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
LCD4X20A::LCD4X20A(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void LCD4X20A::CursorRC(uint8_t Row, uint8_t Col)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B7;
	if((SlaveID & 1) && (*ptr != 'H')) Row = 1;
#endif	
  __innoCommandBuff__[0] = 101;
  __innoCommandBuff__[2] = Col;
  __innoCommandBuff__[3] = Row;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::BackSpace(void)
{
  __innoCommandBuff__[0] = 94;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::Clear(void)
{
  __innoCommandBuff__[0] = 88;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::ClearEOL(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::ClearEOS(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::BacklightOff(void)
{
  __innoCommandBuff__[0] = 121;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::BacklightOn(uint8_t Time)
{
  __innoCommandBuff__[0] = 120;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void LCD4X20A::CursorBlinkOff(void)
{
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorBlinkOn(void)
{
  __innoCommandBuff__[0] = 124;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorOff(void)
{
  __innoCommandBuff__[0] = 123;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorOn(void)
{
  __innoCommandBuff__[0] = 122;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::DisplayOff(void)
{
  __innoCommandBuff__[0] = 133;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::DisplayOn(void)
{
  __innoCommandBuff__[0] = 132;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::RotateLeft(uint8_t Line, uint8_t Spd)
{
  __innoCommandBuff__[0] = 128;
  __innoCommandBuff__[2] = Line;
  __innoCommandBuff__[3] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::RotateOff(void)
{
  __innoCommandBuff__[0] = 130;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::RotateRight(uint8_t Line, uint8_t Spd)
{
  __innoCommandBuff__[0] = 129;
  __innoCommandBuff__[2] = Line;
  __innoCommandBuff__[3] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::SetBacklight(uint8_t Arg)
{
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = Arg;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

void LCD4X20A::Display(const void* ptr, uint8_t len)
{
  char *sptr, *ptr1;
  int8_t i;
  if(len)
  {
      __innoCommandBuff__[0] = 113;
      if(len > 20) len = 20;
      ptr1 = sptr = (char *)ptr;
      for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < len ; __innoCommandBuff__[3]++)
      {
        if(!(*ptr1++)) break;
      }
      if(__innoCommandBuff__[3])
      {
        for(i = 0 ; i < __innoCommandBuff__[3] ; i++)  __innoCommandBuff__[i+4] = *sptr++;
        __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
        __i2cWriteBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6);
      }
  }
}
void LCD4X20A::Display(const void* ptr)
{
  char *sptr, *ptr1;
  int8_t i;
  __innoCommandBuff__[0] = 113;
  ptr1 = sptr = (char *)ptr;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 20 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr1++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++)  __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __i2cWriteBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6);
  }

}

void LCD4X20A::DisplayChar(int8_t c)
{
  __innoCommandBuff__[0] = 115;
  __innoCommandBuff__[2] = c;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}


void LCD4X20A::Display(uint8_t b)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = 0;
  __innoCommandBuff__[3] = b;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::Display(int8_t s)
{
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = 0;
  __innoCommandBuff__[3] = s;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::Display(uint16_t i)
{
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = 0;
  *((int16_t *)&__innoCommandBuff__[3]) = i;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void LCD4X20A::Display(int16_t i)
{
  __innoCommandBuff__[0] = 108;
  __innoCommandBuff__[2] = 0;
  *((int16_t *)&__innoCommandBuff__[3]) = i;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void LCD4X20A::Display(uint32_t dw)
{
  __innoCommandBuff__[0] = 136;
  __innoCommandBuff__[2] = 0;
  *((uint32_t *)&__innoCommandBuff__[3]) = dw;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void LCD4X20A::Display(int32_t l)
{
  __innoCommandBuff__[0] = 137;
  __innoCommandBuff__[2] = 0;
  *((int32_t *)&__innoCommandBuff__[3]) = l;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void LCD4X20A::Display(float f, uint8_t Digits)
{
  char tmpStr[24], Format[8];
  if(Digits > 12) Digits = 12;
  sprintf(Format, "%%.%de", Digits) ;
  sprintf(tmpStr, Format, f) ;
  Display(tmpStr);
}
void LCD4X20A::Display(double f, uint8_t Digits)
{
  char tmpStr[24], Format[8];
  if(Digits > 12) Digits = 12;
  sprintf(Format, "%%.%de", Digits) ;
  sprintf(tmpStr, Format, f) ;
  Display(tmpStr);
}


void LCD4X20A::DisplayBin(uint8_t bb)
{
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = bb;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void LCD4X20A::DisplayBin(uint16_t bw)
{
  __innoCommandBuff__[0] = 110;
  *((uint16_t *)&__innoCommandBuff__[2]) = bw;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::DisplayBin (uint32_t bdw)
{
  __innoCommandBuff__[0] = 138;
  *((uint32_t *)&__innoCommandBuff__[2]) = bdw;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}


void LCD4X20A::DisplayHex(uint8_t hb)
{
  __innoCommandBuff__[0] = 111;
  __innoCommandBuff__[2] = hb;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void LCD4X20A::DisplayHex(uint16_t hw)
{
  __innoCommandBuff__[0] = 112;
  *((uint16_t *)&__innoCommandBuff__[2]) = hw;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void LCD4X20A::DisplayHex(uint32_t hl)
{
  __innoCommandBuff__[0] = 139;
  *((uint32_t *)&__innoCommandBuff__[2]) = hl;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}

void LCD4X20A::DisplayHex(unsigned long long ull)
{
  char tmpStr[24];
  sprintf(tmpStr, "%llx", ull) ;
  Display(tmpStr);
}

void LCD4X20A::Home(void)
{        
  __innoCommandBuff__[0] = 89;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorLeft(void)
{
  __innoCommandBuff__[0] = 89;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorRight(void)
{
  __innoCommandBuff__[0] = 91;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorUp(void)
{
  __innoCommandBuff__[0] = 92;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorDown(void)
{
  __innoCommandBuff__[0] = 93;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::SetTab(uint8_t Tab)
{       
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Tab;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void LCD4X20A::GetTab(uint8_t& Tab)
{
  __innoCommandBuff__[0] = 96;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Tab = __innoCommandBuff__[0];
  }	        
}
void LCD4X20A::Tab(void)
{
  __innoCommandBuff__[0] = 97;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CR(void)
{
  __innoCommandBuff__[0] = 98;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void LCD4X20A::CursorCol(uint8_t Col)
{     
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = Col;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void LCD4X20A::CursorRow(uint8_t Row)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Row;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void LCD4X20A::CustomChar(uint8_t arg0, uint8_t arg1, uint8_t arg2, uint8_t arg3, 
                          uint8_t arg4, uint8_t arg5, uint8_t arg6, uint8_t arg7, uint8_t arg8)
{       
  __innoCommandBuff__[0] = 117;
  __innoCommandBuff__[2] = (arg0 << 5) | arg1;
  __innoCommandBuff__[3] = arg2;
  __innoCommandBuff__[4] = arg3;
  __innoCommandBuff__[5] = arg4;
  __innoCommandBuff__[6] = arg5;
  __innoCommandBuff__[7] = arg6;
  __innoCommandBuff__[8] = arg7;
  __innoCommandBuff__[9] = arg8;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 12);
}
void LCD4X20A::SetBrightness(uint8_t Brightness)
{
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = Brightness;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}





