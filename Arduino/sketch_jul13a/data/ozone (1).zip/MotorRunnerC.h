/**
  ******************************************************************************
  * @file 		MotoRunnerC
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_MOTOR_RUNNER_C
#define __INNO_MOTOR_RUNNER_C
#include "innotype.h" 
class MotorRunnerC
{
    private:
	uint8_t SlaveID;
	public:
	MotorRunnerC(uint8_t);
	void Forward(uint8_t);
	void Backward(uint8_t);
	void SetSpdDC(uint8_t);
	void SetDir(uint8_t);
	void Brake(void);
	void Stop(void);
	void GetDir(uint8_t&);
	void SetTACHPeriod(uint8_t);
	uint8_t TACHIn(uint32_t&);
	void SetSpdCtrl(uint8_t, uint32_t);
	void SpdCtrlOn(void);
	void SpdCtrlOff(void);             
	uint8_t GetSpdCtrlStatus(void);
	void SetP(uint8_t);
	void SetI(uint8_t);
	void SetD(uint8_t);
	void SetScalar(uint8_t);
	void SetCount(uint8_t, uint16_t);
	uint8_t GetCount(uint8_t&, uint16_t&);
	void CountOn(void);
	void CountOff(void);
	uint8_t GetCountStatus(void);
	uint8_t GetBrakeButStatus(void);
	void ClrBrakeButStatus(void);
    uint8_t GetFaultStatus(void);
	void EnFaultStop(void);
	void DisFaultStop(void);
	void ClearFault(void);
	void RestoreStatus(void);

	void GetSpdDC(uint8_t&);
	void GetTACHPeriod(uint8_t&);
	uint8_t GetSpdCtrl(uint8_t&, uint32_t&);
	void SetVel(int16_t);
	void GetVel(int16_t&);
	void GetP(uint8_t&);
	void GetI(uint8_t&);
	void GetD(uint8_t&);
	void GetScalar(uint8_t&);

};
#endif



