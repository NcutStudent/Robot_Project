/**
  ******************************************************************************
  * @file 		MR2X30B
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "MR2X30B.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
MR2X30B::MR2X30B(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
  InitArmCommander();
} 
void MR2X30B::ForwardA(uint16_t DutyCycle)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = DutyCycle;
  __innoCommandBuff__[3] = DutyCycle>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::ForwardB(uint16_t DutyCycle)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B5;
	if(*ptr != 'E') __innoCommandBuff__[0] = 88;
	else 	
#endif	
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = DutyCycle;
  __innoCommandBuff__[3] = DutyCycle>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}  
void MR2X30B::ForwardAB(uint16_t DutyCycleA, uint16_t DutyCycleB)
{
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = DutyCycleA;
  __innoCommandBuff__[3] = DutyCycleA>>8;
  __innoCommandBuff__[4] = DutyCycleB;
  __innoCommandBuff__[5] = DutyCycleB>>8;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void MR2X30B::BackwardA(uint16_t DutyCycle)
{
  __innoCommandBuff__[0] = 92;
  __innoCommandBuff__[2] = DutyCycle;
  __innoCommandBuff__[3] = DutyCycle>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::BackwardB(uint16_t DutyCycle)
{
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = DutyCycle;
  __innoCommandBuff__[3] = DutyCycle>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}	
void MR2X30B::BackwardAB(uint16_t DutyCycleA, uint16_t DutyCycleB)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = DutyCycleA;
  __innoCommandBuff__[3] = DutyCycleA>>8;
  __innoCommandBuff__[4] = DutyCycleB;
  __innoCommandBuff__[5] = DutyCycleB>>8;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void MR2X30B::BrakeA(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X30B::BrakeB(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X30B::BrakeDual(void)
{
  __innoCommandBuff__[0] = 101;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}    	
void MR2X30B::StopA(void)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B3;
	if(*ptr != 'O') __innoCommandBuff__[0] = 97;
	else 	
#endif	
  __innoCommandBuff__[0] = 96;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X30B::StopB(void)
{
  __innoCommandBuff__[0] = 97;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X30B::StopDual(void)
{
  __innoCommandBuff__[0] = 98;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X30B::SetDirAB(uint8_t DirA, uint8_t DirB)
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = DirA;
  __innoCommandBuff__[3] = DirB;	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::SetVelAB(int16_t DutyCycleA, int16_t DutyCycleB)
{
  __innoCommandBuff__[0] = 118;
  *((int16_t *)&__innoCommandBuff__[2]) = DutyCycleA;
  *((int16_t *)&__innoCommandBuff__[4]) = DutyCycleB;	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
uint8_t MR2X30B::GetBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}     
void MR2X30B::ClrBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 124;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);	  	
}
uint8_t MR2X30B::GetFaultStatus(void)
{
  __innoCommandBuff__[0] = 127;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}    
void MR2X30B::ClearFaultStatus(void)
{
  __innoCommandBuff__[0] = 128;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}	
void MR2X30B::EnFaultStop(void)
{
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X30B::DisFaultStop(void)
{
  __innoCommandBuff__[0] = 126;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}     

void MR2X30B::ForwardDual(uint16_t Dutycycle)
{        
  __innoCommandBuff__[0] = 91;
  *((uint16_t *)&__innoCommandBuff__[2]) = Dutycycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::BackwardDual(uint16_t Dutycycle)
{       
  __innoCommandBuff__[0] = 95;
  *((uint16_t *)&__innoCommandBuff__[2]) = Dutycycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::SetDirA(uint8_t Dir)
{  	        
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30B::SetDirB(uint8_t Dir)
{        
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30B::SetDirDual(uint8_t Dir)
{        
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30B::SetDCA(uint16_t Spd)
{          
  __innoCommandBuff__[0] = 106;
  *((uint16_t *)&__innoCommandBuff__[2]) = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::SetDCB(uint16_t Spd)
{      
  __innoCommandBuff__[0] = 107;
  *((uint16_t *)&__innoCommandBuff__[2]) = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::SetDCAB(uint16_t SpdA, uint16_t SpdB)
{     
  __innoCommandBuff__[0] = 108;
  *((uint16_t *)&__innoCommandBuff__[2]) = SpdA;
  *((uint16_t *)&__innoCommandBuff__[4]) = SpdB;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void MR2X30B::SetDCDual(uint16_t Spd)
{        
  __innoCommandBuff__[0] = 109;
  *((uint16_t *)&__innoCommandBuff__[2]) = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30B::GetDCA(uint16_t& Spd)
{  
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Spd = *((uint16_t *)&__innoCommandBuff__[0]);
  }	        
}
void MR2X30B::GetDCB(uint16_t& Spd)
{  
  __innoCommandBuff__[0] = 111;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Spd = *((uint16_t *)&__innoCommandBuff__[0]);
  }	        
}
void MR2X30B::GetDirA(uint8_t& Dir)
{  
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}
void MR2X30B::GetDirB(uint8_t& Dir)
{  
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}
void MR2X30B::GetDCAB(uint16_t& SpdA, uint16_t& SpdB)
{  
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  SpdA = *((uint16_t *)&__innoCommandBuff__[0]);
	  SpdB = *((uint16_t *)&__innoCommandBuff__[2]);
  }	        

}
void MR2X30B::GetDirAB(uint8_t& DirA, uint8_t& DirB)
{  
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  DirA = __innoCommandBuff__[0];
	  DirB = __innoCommandBuff__[1];
  }	        

}
void MR2X30B::SetVelA(int16_t Vel)
{  
  __innoCommandBuff__[0] = 116;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);        
}
void MR2X30B::SetVelB(int16_t Vel)
{  
  __innoCommandBuff__[0] = 117;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);       
}
void MR2X30B::SetVelDual(int16_t Vel)
{  
  __innoCommandBuff__[0] = 119;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);        
}
void MR2X30B::GetVelA(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 120;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }	        
}
void MR2X30B::GetVelB(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 121;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }
}
void MR2X30B::GetVelAB(int16_t& VelA, int16_t& VelB)
{  
  __innoCommandBuff__[0] = 122;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  VelA = *((int16_t *)&__innoCommandBuff__[0]);   
	  VelB = *((int16_t *)&__innoCommandBuff__[2]); 
  }	        
}
uint8_t MR2X30B::GetEncoderValueA(int16_t& Param0)
{
  __innoCommandBuff__[0] = 132;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = __innoCommandBuff__[1] | (__innoCommandBuff__[2]<<8);
    return __innoCommandBuff__[0];  
  }  
  return 0;
}
uint8_t MR2X30B::GetEncoderValueB(int16_t& Param0)
{
  __innoCommandBuff__[0] = 133;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = __innoCommandBuff__[1] | (__innoCommandBuff__[2]<<8);
    return __innoCommandBuff__[0];   
  }
  return 0;  
}
void MR2X30B::SetSpdCtrlA(int16_t Param0, int16_t Param1)
{
  __innoCommandBuff__[0] = 140;
  __innoCommandBuff__[2] = Param0;
  __innoCommandBuff__[3] = Param0>>8;
  __innoCommandBuff__[4] = Param1;
  __innoCommandBuff__[5] = Param1>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);  
}
void MR2X30B::GetSpdCtrlA(int16_t& Param0, int16_t& Param1)
{
  __innoCommandBuff__[0] = 141;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((int16_t *)&__innoCommandBuff__[0]);   
	  Param1 = *((int16_t *)&__innoCommandBuff__[2]); 
  }	  
}
void MR2X30B::PIDCtrlOnA(void)
{
  __innoCommandBuff__[0] = 142;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);   
}
void MR2X30B::PIDCtrlOffA(void)
{
  __innoCommandBuff__[0] = 143;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);    
}
void MR2X30B::SetSpdCtrlB(int16_t Param0, int16_t Param1)
{
  __innoCommandBuff__[0] = 144;
  __innoCommandBuff__[2] = Param0;
  __innoCommandBuff__[3] = Param0>>8;
  __innoCommandBuff__[4] = Param1;
  __innoCommandBuff__[5] = Param1>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);    
}
void MR2X30B::GetSpdCtrlB(int16_t& Param0, int16_t& Param1)
{
  __innoCommandBuff__[0] = 145;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((int16_t *)&__innoCommandBuff__[0]);   
	  Param1 = *((int16_t *)&__innoCommandBuff__[2]); 
  }	  
}
void MR2X30B::PIDCtrlOnB(void)
{
  __innoCommandBuff__[0] = 146;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}
void MR2X30B::PIDCtrlOffB(void)
{
  __innoCommandBuff__[0] = 147;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);    
}
void MR2X30B::PIDCtrlOnAB(void)
{
  __innoCommandBuff__[0] = 148;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);    
}
void MR2X30B::PIDCtrlOffAB(void)
{
  __innoCommandBuff__[0] = 149;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);    
}
void MR2X30B::SetScalarA(uint8_t Param0)
{
  __innoCommandBuff__[0] = 156;
  __innoCommandBuff__[2] = Param0;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);    
}
void MR2X30B::GetScalarA(uint8_t& Param0)
{
  __innoCommandBuff__[0] = 157;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = __innoCommandBuff__[0];   
  }   
}
void MR2X30B::SetScalarB(uint8_t Param0)
{
  __innoCommandBuff__[0] = 164;
  __innoCommandBuff__[2] = Param0;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);    
}
void MR2X30B::GetScalarB(uint8_t& Param0)
{
  __innoCommandBuff__[0] = 165;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = __innoCommandBuff__[0];   
  }   
}
void MR2X30B::SetEncoderModeA(uint16_t Param0)
{
  __innoCommandBuff__[0] = 170;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8; 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);    
}
void MR2X30B::GetEncoderModeA(uint16_t& Param0)
{
  __innoCommandBuff__[0] = 171;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((uint16_t *)&__innoCommandBuff__[0]);   
  }   
}
void MR2X30B::SetEncoderModeB(uint16_t Param0)
{
  __innoCommandBuff__[0] = 172;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8; 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);    
}
void MR2X30B::GetEncoderModeB(uint16_t& Param0)
{
  __innoCommandBuff__[0] = 173;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((uint16_t *)&__innoCommandBuff__[0]);   
  }   
}
void MR2X30B::SetPIDA(uint8_t Param0, uint8_t Param1, uint8_t Param2)
{
  __innoCommandBuff__[0] = 174;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param1; 
  __innoCommandBuff__[4] = Param2;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);   
}
void MR2X30B::SetPIDB(uint8_t Param0, uint8_t Param1, uint8_t Param2)
{
  __innoCommandBuff__[0] = 175;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param1; 
  __innoCommandBuff__[4] = Param2;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);   
}
void MR2X30B::SetTargetEncoderValueA(int16_t Param0)
{
  __innoCommandBuff__[0] = 176;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);     
}
void MR2X30B::GetTargetEncoderValueA(int16_t& Param0)
{
  __innoCommandBuff__[0] = 177;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((int16_t *)&__innoCommandBuff__[0]);   
  }   
}
void MR2X30B::SetTargetEncoderValueB(int16_t Param0)
{
  __innoCommandBuff__[0] = 178;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);    
}
void MR2X30B::GetTargetEncoderValueB(int16_t& Param0)
{
  __innoCommandBuff__[0] = 179;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((int16_t *)&__innoCommandBuff__[0]);   
  }  
}
void MR2X30B::SetEncoderValueA(int16_t Param0)
{
  __innoCommandBuff__[0] = 180;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);  
}
void MR2X30B::SetEncoderValueB(int16_t Param0)
{
  __innoCommandBuff__[0] = 181;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);  
}
void MR2X30B::GetPIDA(uint8_t& Param0, uint8_t& Param1, uint8_t& Param2)
{
  __innoCommandBuff__[0] = 182;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = __innoCommandBuff__[0];   
	  Param1 = __innoCommandBuff__[1];
    Param2 = __innoCommandBuff__[2];  
  }	  
}
void MR2X30B::GetPIDB(uint8_t& Param0, uint8_t& Param1, uint8_t& Param2)
{
  __innoCommandBuff__[0] = 183;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = __innoCommandBuff__[0];   
	  Param1 = __innoCommandBuff__[1];
    Param2 = __innoCommandBuff__[2];    
  }	  
}
void MR2X30B::SetDeadZoneA(uint16_t Param0)
{
  __innoCommandBuff__[0] = 184;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);    
}
void MR2X30B::SetDeadZoneB(uint16_t Param0)
{
  __innoCommandBuff__[0] = 185;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);  
}
void MR2X30B::GetDeadZoneA(uint16_t& Param0)
{
  __innoCommandBuff__[0] = 186;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((uint16_t *)&__innoCommandBuff__[0]);   
  }	  
}
void MR2X30B::GetDeadZoneB(uint16_t& Param0)
{
  __innoCommandBuff__[0] = 187;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((uint16_t *)&__innoCommandBuff__[0]);  
  }	  
}
void MR2X30B::SetRampA(uint16_t Param0)
{
  __innoCommandBuff__[0] = 188;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);  
}  
void MR2X30B::GetRampA(uint16_t& Param0)
{
  __innoCommandBuff__[0] = 189;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((uint16_t *)&__innoCommandBuff__[0]);  
  }	  
}
void MR2X30B::SetRampB(uint16_t Param0)
{
  __innoCommandBuff__[0] = 190;
  __innoCommandBuff__[2] = Param0;  
  __innoCommandBuff__[3] = Param0>>8;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);  
}  
void MR2X30B::GetRampB(uint16_t& Param0)
{
  __innoCommandBuff__[0] = 191;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3,  &__innoNumByteToRead__))
  {
	  Param0 = *((uint16_t *)&__innoCommandBuff__[0]);  
  }	  
}

