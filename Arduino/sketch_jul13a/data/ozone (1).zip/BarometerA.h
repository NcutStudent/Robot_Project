/**
  ******************************************************************************
  * @file 		MotoRunnerB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_BAROMETER_A
#define __INNO_BAROMETER_A	   
#include "innotype.h"
class BarometerA
{
    private:
	uint8_t SlaveID;
	public:
	BarometerA(uint8_t);
	void GetPressuremBar(float &);
	void GetAltitude10Feet(int32_t &);
	void SetSeaLevelPressure(uint16_t);
	void SetMode(uint8_t);	 
    
	void GetAltitudeFeet(float &);
	void SetRecordPressureCnt(uint16_t);
	void SetRecordAltitudeCnt(uint16_t);
	void StartAutoPressureRecord(void);
	void StartAutoAltitudeRecord(void);
	void StopAutoPressureRecord(void);
	void StopAutoAltitudeRecord(void);
	void SaveCurPressure(uint8_t);
	void SaveCurAltitude(uint8_t);
	void LoadPressure10mBar(uint8_t, uint16_t&);
	void LoadPressuremBar(uint8_t, float&);
	void LoadAltitude10Feet(uint8_t, uint32_t&);
	void LoadAltitudeFeet(uint8_t, float&);
	uint8_t GetPressureAlarmStatus(void);
	uint8_t GetAltitudeAlarmStatus(void);
	void GetRecordPressureCnt(uint16_t&);
	void GetRecordAltitudeCnt(uint16_t&);
	uint8_t GetRefreshStatus(void);
	void GetSeaLevelPressure(uint16_t&);
	void GetMode(uint8_t&);    
    
};
#endif



