/**
  ******************************************************************************
  * @file 		COLORRGB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "ColorRGB.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
ColorRGB::ColorRGB(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();

}
void ColorRGB::LoadLED(void)
{
  __innoCommandBuff__[0] = 127;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);

}    
void ColorRGB::SetPrescalar(uint8_t Scalar)
{
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = Scalar;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
uint8_t ColorRGB::GetRGB(uint16_t &Red, uint16_t &Green, uint16_t &Blue)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 8;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Red = *((uint16_t *)&__innoCommandBuff__[1]); 
	  Green = *((uint16_t *)&__innoCommandBuff__[3]);
	  Blue = *((uint16_t *)&__innoCommandBuff__[5]);
      return __innoCommandBuff__[0];
  }	          	  
  return 0;
}
uint8_t ColorRGB::GetCRGB(uint16_t &Clear, uint16_t &Red, uint16_t &Green, uint16_t &Blue)
{
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 10;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Clear = *((uint16_t *)&__innoCommandBuff__[1]); 
	  Red = *((uint16_t *)&__innoCommandBuff__[3]); 
	  Green = *((uint16_t *)&__innoCommandBuff__[5]);
	  Blue = *((uint16_t *)&__innoCommandBuff__[7]);
      return __innoCommandBuff__[0];
  }	      	  	 
  return 0; 
}
void ColorRGB::StartMeasure(void)
{
  __innoCommandBuff__[0] = 128;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ColorRGB::TurnOnLED(void)
{
  __innoCommandBuff__[0] = 111;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ColorRGB::TurnOffLED(void)
{
  __innoCommandBuff__[0] = 112;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ColorRGB::SetLEDRGB(uint8_t Red, uint8_t Green, uint8_t Blue)
{
  __innoCommandBuff__[0] = 124;
  __innoCommandBuff__[2] = Red;
  __innoCommandBuff__[3] = Green;
  __innoCommandBuff__[4] = Blue;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ColorRGB::ScaleLED(uint8_t Scale)
{
  __innoCommandBuff__[0] = 126;
  __innoCommandBuff__[2] = Scale;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ColorRGB::SetPeriod(uint8_t Period)
{
  __innoCommandBuff__[0] = 114;
  __innoCommandBuff__[2] = Period;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ColorRGB::SetGain(uint8_t Scale)
{
  __innoCommandBuff__[0] = 116;
  __innoCommandBuff__[2] = Scale;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ColorRGB::SetPrescaler(uint8_t Prescaler)
{
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = Prescaler;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
		  

void ColorRGB::GetClear(uint16_t& Clear)
{
  __innoCommandBuff__[0] = 88;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Clear = *((uint16_t *)&__innoCommandBuff__);  
  }	        

}
void ColorRGB::GetBlue(uint16_t& Blue)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Blue = *((uint16_t *)&__innoCommandBuff__);  
  }	      
}
void ColorRGB::GetGreen(uint16_t& Green)
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Green = *((uint16_t *)&__innoCommandBuff__); 
  }	        
}
void ColorRGB::GetRed(uint16_t& Red)
{
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Red = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}
void ColorRGB::SaveCurColorVal(uint8_t Num)
{       
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ColorRGB::SaveColorDes(uint8_t Num, uint8_t DesR, uint8_t DesG, uint8_t DesB)
{    
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Num;
  __innoCommandBuff__[3] = DesR;
  __innoCommandBuff__[4] = DesG;
  __innoCommandBuff__[5] = DesB;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void ColorRGB::SaveColorVal(uint8_t Num, uint16_t ValueC, uint16_t ValueR, uint16_t ValueG, uint16_t ValueB)
{	        
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = Num;
  *((uint16_t *)&__innoCommandBuff__[3]) = ValueC;
  *((uint16_t *)&__innoCommandBuff__[5]) = ValueR;
  *((uint16_t *)&__innoCommandBuff__[7]) = ValueG;    
  *((uint16_t *)&__innoCommandBuff__[9]) = ValueB;     
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 13);
}
void ColorRGB::SaveColorInfo(uint8_t Num, uint8_t DesR, uint8_t DesG, uint8_t DesB,
                                          uint16_t ValueC, uint16_t ValueR, uint16_t ValueG, uint16_t ValueB) 
{	        
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ColorRGB::GetColorVal(uint8_t Num, uint16_t& ValueC, uint16_t& ValueR, uint16_t& ValueG, uint16_t& ValueB)
{
  __innoCommandBuff__[0] = 98;
    __innoCommandBuff__[2] = Num;
  __innoNumByteToRead__ = 9;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
      ValueC = *((uint16_t *)&__innoCommandBuff__[0]);
      ValueR = *((uint16_t *)&__innoCommandBuff__[2]);
      ValueG = *((uint16_t *)&__innoCommandBuff__[4]);    
      ValueB = *((uint16_t *)&__innoCommandBuff__[6]);  
  }	        
}
void ColorRGB::GetColorDes(uint8_t, uint8_t& DesR, uint8_t& DesG, uint8_t& DesB)
{
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
      DesR = __innoCommandBuff__[0];
      DesG = __innoCommandBuff__[1];
      DesB = __innoCommandBuff__[2];  
  }	        
}
void ColorRGB::MatchColorDesAll(uint8_t DesR, uint8_t DesG, uint8_t DesB)
{
  __innoCommandBuff__[0] = 100;
  __innoCommandBuff__[2] = DesR;
  __innoCommandBuff__[3] = DesG;
  __innoCommandBuff__[4] = DesB;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ColorRGB::MatchColorDesIndex(uint8_t DesR, uint8_t DesG, uint8_t DesB, uint8_t Min, uint8_t High)
{
  __innoCommandBuff__[0] = 101;
  __innoCommandBuff__[2] = DesR;
  __innoCommandBuff__[3] = DesG;
  __innoCommandBuff__[4] = DesB;    
  __innoCommandBuff__[5] = Min;    
  __innoCommandBuff__[6] = High;        
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void ColorRGB::MatchCurColorAll(void)
{      
  __innoCommandBuff__[0] = 102;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ColorRGB::MatchCurColorIndex(uint8_t Min, uint8_t High)
{     
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Min;
  __innoCommandBuff__[3] = High;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void ColorRGB::MatchCurColorRGBAll(void)
{      
  __innoCommandBuff__[0] = 104;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ColorRGB::MatchCurColorRGBIndex(uint8_t Min, uint8_t High)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Min;
  __innoCommandBuff__[3] = High;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void ColorRGB::GetMatchNum(uint8_t& Num)
{
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Num = __innoCommandBuff__[2];
  }	        
}
void ColorRGB::GetMatchNeighborNum(uint8_t& Num1, uint8_t& Num2, uint8_t& Num3)
{
  __innoCommandBuff__[0] = 107;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Num1 = __innoCommandBuff__[0];   
	  Num2 = __innoCommandBuff__[1];
	  Num3 = __innoCommandBuff__[2];      
  }	        
}
uint8_t ColorRGB::GetMatchStatus(void)
{
  __innoCommandBuff__[0] = 108;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);
  }	        
  return 0;
}
void ColorRGB::GetMatchDiff(int16_t& DiffC, int16_t& DiffR, int16_t& DiffG, int16_t& DiffB)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 9;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DiffC = *((uint16_t *)&__innoCommandBuff__);   
	  DiffR = *((uint16_t *)&__innoCommandBuff__[2]); 
      DiffG = *((uint16_t *)&__innoCommandBuff__[4]); 
      DiffB = *((uint16_t *)&__innoCommandBuff__[6]); 
  }	        
}
void ColorRGB::GetMatchDiffAll(uint16_t& Diff)
{
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Diff = *((uint16_t *)&__innoCommandBuff__); 
  }	        
}
void ColorRGB::GetLEDStatus(uint8_t& Status)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Status = __innoCommandBuff__[0];
  }	        
}
void ColorRGB::GetPeriod(uint8_t& Period)
{
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Period = __innoCommandBuff__[0];
  }	        
}
void ColorRGB::GetGain(uint8_t& Gain)
{
  __innoCommandBuff__[0] = 117;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Gain = __innoCommandBuff__[0];
  }	       
}
void ColorRGB::GetPrescalar(uint8_t& Prescalar)
{
  __innoCommandBuff__[0] = 119;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Prescalar = __innoCommandBuff__[0];
  }	        
}
void ColorRGB::GetLEDRGB(uint8_t& R, uint8_t& G, uint8_t& B)
{
  __innoCommandBuff__[0] = 125;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  R = __innoCommandBuff__[0];   
	  G = __innoCommandBuff__[1];
      B = __innoCommandBuff__[2];
  }	        
}
void ColorRGB::SetMatchMaxDiff(uint16_t Diff)
{
  __innoCommandBuff__[0] = 131;
  *((uint16_t *)&__innoCommandBuff__[2]) = Diff;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}  

void ColorRGB::GetMatchMaxDiff(uint16_t& Diff)
{
  __innoCommandBuff__[0] = 132;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Diff = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}  


