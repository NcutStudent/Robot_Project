/**
  ******************************************************************************
  * @file 		RF24G
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body                                                                                                                                      {                        
                                                                                                                                      {                        
                                                                                                                                      {                        
                                                                                                                                      {                        

  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_RF24G__
#define __INNO_RF24G__	  
#include "innotype.h" 
class RF24G
{
    private:
	uint8_t SlaveID;
	public:
	RF24G(uint8_t);
	void SendVar(char);
	void SendVar(int8_t);    
	void SendVar(uint8_t);
	void SendVar(int16_t);
	void SendVar(uint16_t);
	void SendVar(int32_t);
	void SendVar(uint32_t);
	void SendArray(const void*);
	void SendString(const void*);
	void GetVar(uint8_t&);
	void GetVar(char&);
	void GetVar(int8_t&);    
	void GetVar(uint16_t&);
	void GetVar(int16_t&);
	void GetVar(uint32_t&);
	void GetVar(int32_t&);
	void GetArray(void*);
	void GetString(void*);
	void ClrBuffer(void);
	void SetMode(uint8_t);
	void SetCh(uint8_t);
	void SetRFID(uint8_t);
	void SetRegCode(uint8_t);
	void Config(void);
	void BufferVar(uint8_t, uint32_t);
	void BufferArray(void*);
	void BufferString(void*);
	void SendBuffer(void);
	uint8_t GetStatus(void);

};
#endif



