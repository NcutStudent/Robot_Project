/**
  ******************************************************************************
  * @file 		SonarA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_SONAR_A
#define __INNO_SONAR_A	
#include "innotype.h" 
class SonarA
{
    private:
	uint8_t SlaveID;
	public:
	SonarA(uint8_t);
	void SetFloorLevel(uint8_t);
	void Ranging(void);
	void RepeatRanging(void);
	void StopRanging(void);
	uint8_t GetDistance(uint8_t, uint16_t &);
    
	void SetRangingTime(uint8_t);
	void GetRangingTime(uint8_t&);
	void SetBurstPower(uint8_t);
	void GetBurstPower(uint8_t&);
	void SetRepeatCount(uint8_t);
	void SetRepeatTime(uint8_t);
	void GetRepeatCount(uint8_t&);
	void GetRepeatTime(uint8_t&);
	void GetFloorLevel(uint8_t&);
    
};
#endif



