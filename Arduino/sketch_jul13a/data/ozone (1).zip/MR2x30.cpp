/**
  ******************************************************************************
  * @file 		MR2x30
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "MR2X30.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
MR2X30::MR2X30(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void MR2X30::ForwardA(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::ForwardB(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}  
void MR2X30::ForwardAB(uint8_t DutyCycleA, uint8_t DutyCycleB)
{
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = DutyCycleA;
  __innoCommandBuff__[3] = DutyCycleB;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30::BackwardA(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 92;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::BackwardB(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}	
void MR2X30::BackwardAB(uint8_t DutyCycleA, uint8_t DutyCycleB)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = DutyCycleA;
  __innoCommandBuff__[3] = DutyCycleB;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30::BrakeA(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X30::BrakeB(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X30::BrakeDual(void)
{
  __innoCommandBuff__[0] = 101;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}    	
void MR2X30::StopA(void)
{
  __innoCommandBuff__[0] = 96;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X30::StopB(void)
{
  __innoCommandBuff__[0] = 97;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X30::StopDual(void)
{
  __innoCommandBuff__[0] = 98;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X30::SetDirAB(uint8_t DirA, uint8_t DirB)
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = DirA;
  __innoCommandBuff__[3] = DirB;	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30::SetVelAB(int16_t DutyCycleA, int16_t DutyCycleB)
{
  __innoCommandBuff__[0] = 118;
  *((int16_t *)&__innoCommandBuff__[2]) = DutyCycleA;
  *((int16_t *)&__innoCommandBuff__[4]) = DutyCycleB;	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
uint8_t MR2X30::GetBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}     
void MR2X30::ClrBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 124;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);	  	
}
uint8_t MR2X30::GetFaultStatus(void)
{
  __innoCommandBuff__[0] = 127;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}    
void MR2X30::ClearFaultStatus(void)
{
  __innoCommandBuff__[0] = 128;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}	
void MR2X30::EnFaultStop(void)
{
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X30::DisFaultStop(void)
{
  __innoCommandBuff__[0] = 126;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}     

void MR2X30::ForwardDual(uint8_t Dutycycle)
{        
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = Dutycycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::BackwardDual(uint8_t Dutycycle)
{       
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Dutycycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::SetDirA(uint8_t Dir)
{  	        
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::SetDirB(uint8_t Dir)
{        
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::SetDirDual(uint8_t Dir)
{        
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::SetDCA(uint8_t Spd)
{          
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::SetDCB(uint8_t Spd)
{      
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::SetDCAB(uint8_t SpdA, uint8_t SpdB)
{     
  __innoCommandBuff__[0] = 108;
  __innoCommandBuff__[2] = SpdA;
  __innoCommandBuff__[3] = SpdB;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X30::SetDCDual(uint8_t Spd)
{        
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X30::GetDCA(uint8_t& Spd)
{  
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Spd = __innoCommandBuff__[0];
  }	        
}
void MR2X30::GetDCB(uint8_t& Spd)
{  
  __innoCommandBuff__[0] = 111;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Spd = __innoCommandBuff__[0];
  }	        
}
void MR2X30::GetDirA(uint8_t& Dir)
{  
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}
void MR2X30::GetDirB(uint8_t& Dir)
{  
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}
void MR2X30::GetDCAB(uint8_t& SpdA, uint8_t& SpdB)
{  
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  SpdA = __innoCommandBuff__[0];
	  SpdB = __innoCommandBuff__[1];
  }	        

}
void MR2X30::GetDirAB(uint8_t& DirA, uint8_t& DirB)
{  
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DirA = __innoCommandBuff__[0];
	  DirB = __innoCommandBuff__[1];
  }	        

}
void MR2X30::SetVelA(int16_t Vel)
{  
  __innoCommandBuff__[0] = 116;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);        
}
void MR2X30::SetVelB(int16_t Vel)
{  
  __innoCommandBuff__[0] = 117;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);       
}
void MR2X30::SetVelDual(int16_t Vel)
{  
  __innoCommandBuff__[0] = 119;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);        
}
void MR2X30::GetVelA(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 120;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }	        
}
void MR2X30::GetVelB(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 121;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }
}
void MR2X30::GetVelAB(int16_t& VelA, int16_t& VelB)
{  
  __innoCommandBuff__[0] = 122;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  VelA = *((int16_t *)&__innoCommandBuff__[0]);   
	  VelB = *((int16_t *)&__innoCommandBuff__[2]); 
  }	        
}


