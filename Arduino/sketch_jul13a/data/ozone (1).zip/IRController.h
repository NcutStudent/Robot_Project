/**
  ******************************************************************************
  * @file 		IOExtenderA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_IRCONTROLLER
#define __INNO_IRCONTROLLER	 
#include "innotype.h"
class IRController
{
    private:
	uint8_t SlaveID;
	public:
	IRController(uint8_t);
    void GetMaxID(uint8_t &);
    void GetMaxVal(uint16_t &);
    void GetVal(uint8_t, uint16_t&);
    void GetMinID(uint8_t&);
    void GetMinVal(uint16_t&);
    void GetAvgVal(uint16_t&);
    void GetMax(uint8_t&, uint16_t&);
    void GetMin(uint8_t&, uint16_t&);
    void SetThreshold(int16_t);
    void GetThreshold(int16_t &);
    uint8_t GetIRStatus(void);	       
};
#endif



