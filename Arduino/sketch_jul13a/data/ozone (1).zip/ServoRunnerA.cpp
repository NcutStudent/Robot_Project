/**
  ******************************************************************************
  * @file 		ServoRunnerA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "ServoRunnerA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
ServoRunnerA::ServoRunnerA(uint8_t mySlaveID)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B7;
	if(*ptr != 'H') mySlaveID = 0;
#endif	
	SlaveID = mySlaveID;
    InitArmCommander();
}
void ServoRunnerA::SetPosAndRun(uint8_t SerID, uint16_t Pos)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = SerID;
  *((uint16_t *)&__innoCommandBuff__[3]) = Pos;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ServoRunnerA::SetPosSpdAndRun(uint8_t SerID, uint16_t Pos, uint16_t Spd)
{
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = SerID;
  *((uint16_t *)&__innoCommandBuff__[3]) = Pos;
  *((uint16_t *)&__innoCommandBuff__[5]) = Spd;	      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void ServoRunnerA::SetPosTimeAndRun(uint8_t SerID, uint16_t Pos, uint16_t Time)
{
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = SerID;
  *((uint16_t *)&__innoCommandBuff__[3]) = Pos;
  *((uint16_t *)&__innoCommandBuff__[5]) = Time;	      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void ServoRunnerA::SetPos(uint8_t SerID, uint16_t Pos)
{
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = SerID;
  *((uint16_t *)&__innoCommandBuff__[3]) = Pos; 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ServoRunnerA::SetPosSpd(uint8_t SerID, uint16_t Pos, uint16_t Spd)
{
  __innoCommandBuff__[0] = 92;
  __innoCommandBuff__[2] = SerID;
  *((uint16_t *)&__innoCommandBuff__[3]) = Pos;
  *((uint16_t *)&__innoCommandBuff__[5]) = Spd;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ServoRunnerA::SetPosTime(uint8_t SerID, uint16_t Pos, uint16_t Time)
{
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = SerID;
  *((uint16_t *)&__innoCommandBuff__[3]) = Pos;
  *((uint16_t *)&__innoCommandBuff__[5]) = Time;	 	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ServoRunnerA::Run1Servo(uint8_t S1)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = S1;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ServoRunnerA::Run2Servo(uint8_t S1, uint8_t S2)
{
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void ServoRunnerA::Run3Servo(uint8_t S1, uint8_t S2, uint8_t S3)
{
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ServoRunnerA::Run4Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;		  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void ServoRunnerA::Run5Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5)
{
  __innoCommandBuff__[0] = 98;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void ServoRunnerA::Run6Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6)
{
  __innoCommandBuff__[0] = 99;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6;  	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void ServoRunnerA::Run7Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7)
{
  __innoCommandBuff__[0] = 100;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7;   	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 11);
}
void ServoRunnerA::Run8Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
               uint8_t int8_t)
{
  __innoCommandBuff__[0] = 101;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 	      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 12);
}
void ServoRunnerA::Run9Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9)
{
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t;
  __innoCommandBuff__[10] = S9;       	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 13);
}
void ServoRunnerA::Run10Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 14);
}
void ServoRunnerA::Run11Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11)	
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 15);
}
void ServoRunnerA::Run12Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12)	
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 16);
}
void ServoRunnerA::Run13Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	            uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13)	
{
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t;
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13;        	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 17);
}
void ServoRunnerA::Run14Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13, uint8_t S14)	
{
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 	 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13; 
  __innoCommandBuff__[15] = S14; 	        
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 18);
}
void ServoRunnerA::Run15Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	            uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13, uint8_t S14, uint8_t S15)	
{
  __innoCommandBuff__[0] = 108;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13; 
  __innoCommandBuff__[15] = S14; 	  
  __innoCommandBuff__[16] = S15; 	      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 19);
}
void ServoRunnerA::RunAllServo(void)
{
  __innoCommandBuff__[0] = 109;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}  

void ServoRunnerA::Pause1Servo(uint8_t S1)
{
  __innoCommandBuff__[0] = 197;
  __innoCommandBuff__[2] = S1;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ServoRunnerA::Pause2Servo(uint8_t S1, uint8_t S2)
{
  __innoCommandBuff__[0] = 198;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void ServoRunnerA::Pause3Servo(uint8_t S1, uint8_t S2, uint8_t S3)
{
  __innoCommandBuff__[0] = 199;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ServoRunnerA::Pause4Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4)
{
  __innoCommandBuff__[0] = 200;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;		  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void ServoRunnerA::Pause5Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5)
{
  __innoCommandBuff__[0] = 201;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void ServoRunnerA::Pause6Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6)
{
  __innoCommandBuff__[0] = 202;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6;  	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void ServoRunnerA::Pause7Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7)
{
  __innoCommandBuff__[0] = 203;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7;   	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 11);
}
void ServoRunnerA::Pause8Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
               uint8_t int8_t)
{
  __innoCommandBuff__[0] = 204;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 	      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 12);
}
void ServoRunnerA::Pause9Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9)
{
  __innoCommandBuff__[0] = 205;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t;
  __innoCommandBuff__[10] = S9;       	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 13);
}
void ServoRunnerA::Pause10Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10)
{
  __innoCommandBuff__[0] = 206;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 14);
}
void ServoRunnerA::Pause11Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11)	
{
  __innoCommandBuff__[0] = 207;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 15);
}
void ServoRunnerA::Pause12Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12)	
{
  __innoCommandBuff__[0] = 208;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 16);
}
void ServoRunnerA::Pause13Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	            uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13)	
{
  __innoCommandBuff__[0] = 209;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t;
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13;        	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 17);
}
void ServoRunnerA::Pause14Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13, uint8_t S14)	
{
  __innoCommandBuff__[0] = 210;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 	 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13; 
  __innoCommandBuff__[15] = S14; 	        
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 18);
}
void ServoRunnerA::Pause15Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	            uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13, uint8_t S14, uint8_t S15)	
{
  __innoCommandBuff__[0] = 211;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13; 
  __innoCommandBuff__[15] = S14; 	  
  __innoCommandBuff__[16] = S15; 	      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 19);
}
void ServoRunnerA::PauseAllServo(void)
{
  __innoCommandBuff__[0] = 212;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ServoRunnerA::Stop1Servo(uint8_t S1)
{
  __innoCommandBuff__[0] = 213;
  __innoCommandBuff__[2] = S1;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void ServoRunnerA::Stop2Servo(uint8_t S1, uint8_t S2)
{
  __innoCommandBuff__[0] = 214;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void ServoRunnerA::Stop3Servo(uint8_t S1, uint8_t S2, uint8_t S3)
{
  __innoCommandBuff__[0] = 215;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void ServoRunnerA::Stop4Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4)
{
  __innoCommandBuff__[0] = 216;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;		  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void ServoRunnerA::Stop5Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5)
{
  __innoCommandBuff__[0] = 217;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void ServoRunnerA::Stop6Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6)
{
  __innoCommandBuff__[0] = 218;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6;  	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void ServoRunnerA::Stop7Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7)
{
  __innoCommandBuff__[0] = 219;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7;   	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 11);
}
void ServoRunnerA::Stop8Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
               uint8_t int8_t)
{
  __innoCommandBuff__[0] = 220;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 	      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 12);
}
void ServoRunnerA::Stop9Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9)
{
  __innoCommandBuff__[0] = 221;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t;
  __innoCommandBuff__[10] = S9;       	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 13);
}
void ServoRunnerA::Stop10Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10)
{
  __innoCommandBuff__[0] = 222;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 14);
}
void ServoRunnerA::Stop11Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11)	
{
  __innoCommandBuff__[0] = 223;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 15);
}
void ServoRunnerA::Stop12Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12)	
{
  __innoCommandBuff__[0] = 224;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 16);
}
void ServoRunnerA::Stop13Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	            uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13)	
{
  __innoCommandBuff__[0] = 225;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t;
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13;        	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 17);
}
void ServoRunnerA::Stop14Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	           uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13, uint8_t S14)	
{
  __innoCommandBuff__[0] = 226;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 	 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13; 
  __innoCommandBuff__[15] = S14; 	        
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 18);
}
void ServoRunnerA::Stop15Servo(uint8_t S1, uint8_t S2, uint8_t S3, uint8_t S4, uint8_t S5, uint8_t S6, uint8_t S7,
	            uint8_t int8_t, uint8_t S9, uint8_t S10, uint8_t S11, uint8_t S12, uint8_t S13, uint8_t S14, uint8_t S15)	
{
  __innoCommandBuff__[0] = 227;
  __innoCommandBuff__[2] = S1;
  __innoCommandBuff__[3] = S2;
  __innoCommandBuff__[4] = S3;	  
  __innoCommandBuff__[5] = S4;	
  __innoCommandBuff__[6] = S5;
  __innoCommandBuff__[7] = S6; 
  __innoCommandBuff__[8] = S7; 	  
  __innoCommandBuff__[9] = int8_t; 
  __innoCommandBuff__[10] = S9;
  __innoCommandBuff__[11] = S10;	  
  __innoCommandBuff__[12] = S11;	
  __innoCommandBuff__[13] = S12;
  __innoCommandBuff__[14] = S13; 
  __innoCommandBuff__[15] = S14; 	  
  __innoCommandBuff__[16] = S15; 	      	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 19);
}
void ServoRunnerA::StopAllServo(void)
{
  __innoCommandBuff__[0] = 228;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void ServoRunnerA::LoadFrame(uint8_t FrameNo)
{
  __innoCommandBuff__[0] = 196;
  __innoCommandBuff__[2] = FrameNo;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}   
void ServoRunnerA::SaveFrame(uint8_t FrameNo)
{
  __innoCommandBuff__[0] = 195;
  __innoCommandBuff__[2] = FrameNo;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}   
void ServoRunnerA::LoadOffset(void)
{
  __innoCommandBuff__[0] = 230;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}   
void ServoRunnerA::SaveOffset(void)
{
  __innoCommandBuff__[0] = 229;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}   
void ServoRunnerA::SetPosOffset(uint8_t SerID, int8_t Offset) 
{
  __innoCommandBuff__[0] = 193;
  __innoCommandBuff__[2] = SerID;
  __innoCommandBuff__[3] = Offset;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}   
                                                              	

void ServoRunnerA::Get1ServoReadyStatus(uint8_t ID0, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 174;
  __innoCommandBuff__[2] = ID0;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::Get2ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 175;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 6, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::Get3ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 176;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;      
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 7, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::Get4ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 177;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;  
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 8, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::Get5ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                        uint8_t ID4, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 178;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4; 
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 9, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::Get6ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                        uint8_t ID4, uint8_t ID5, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 179;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;    
  __innoCommandBuff__[7] = ID5;      
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 10, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::Get7ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                        uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 180;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;      
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 11, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get8ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                        uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 181;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;      
  __innoCommandBuff__[9] = ID7;  
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 12, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get9ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                        uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7, 
                                        uint8_t ID8, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 182;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;  
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;    
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 13, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get10ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                         uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7, 
                                         uint8_t ID8, uint8_t ID9, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 183;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;  
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;
  __innoCommandBuff__[11] = ID9;    
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 14, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get11ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                         uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7, 
                                         uint8_t ID8, uint8_t ID9, uint8_t ID10, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 184;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;  
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;
  __innoCommandBuff__[11] = ID9;
  __innoCommandBuff__[12] = ID10;     
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 15, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get12ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                         uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7,                                          
                                         uint8_t ID8, uint8_t ID9, uint8_t ID10, uint8_t ID11,
                                         uint8_t& Status)
{  
  __innoCommandBuff__[0] = 185;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;   
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;
  __innoCommandBuff__[11] = ID9;
  __innoCommandBuff__[12] = ID10;    
  __innoCommandBuff__[13] = ID11;     
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 16, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get13ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                         uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7,
                                         uint8_t ID8, uint8_t ID9, uint8_t ID10, uint8_t ID11,  
                                         uint8_t ID12, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 186;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;     
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;
  __innoCommandBuff__[11] = ID9;
  __innoCommandBuff__[12] = ID10;    
  __innoCommandBuff__[13] = ID11;  
  __innoCommandBuff__[14] = ID12;      
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 17, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get14ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                         uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7, 
                                         uint8_t ID8, uint8_t ID9, uint8_t ID10, uint8_t ID11, 
                                         uint8_t ID12, uint8_t ID13, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 187;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;      
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;
  __innoCommandBuff__[11] = ID9;
  __innoCommandBuff__[12] = ID10;    
  __innoCommandBuff__[13] = ID11;  
  __innoCommandBuff__[14] = ID12;    
  __innoCommandBuff__[15] = ID13;     
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 18, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}
void ServoRunnerA::Get15ServoReadyStatus(uint8_t ID0, uint8_t ID1, uint8_t ID2, uint8_t ID3, 
                                         uint8_t ID4, uint8_t ID5, uint8_t ID6, uint8_t ID7, 
                                         uint8_t ID8, uint8_t ID9, uint8_t ID10, uint8_t ID11, 
                                         uint8_t ID12, uint8_t ID13, uint8_t ID14, uint8_t& Status)
{  
  __innoCommandBuff__[0] = 188;
  __innoCommandBuff__[2] = ID0;
  __innoCommandBuff__[3] = ID1;
  __innoCommandBuff__[4] = ID2;
  __innoCommandBuff__[5] = ID3;    
  __innoCommandBuff__[6] = ID4;  
  __innoCommandBuff__[7] = ID5;    
  __innoCommandBuff__[8] = ID6;     
  __innoCommandBuff__[9] = ID7;
  __innoCommandBuff__[10] = ID8;
  __innoCommandBuff__[11] = ID9;
  __innoCommandBuff__[12] = ID10;    
  __innoCommandBuff__[13] = ID11;  
  __innoCommandBuff__[14] = ID12;    
  __innoCommandBuff__[15] = ID13; 
  __innoCommandBuff__[16] = ID14;        
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 19, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}

void ServoRunnerA::GetAllServoReadyStatus(uint8_t& Status)
{  
  __innoCommandBuff__[0] = 189;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0];
  }	        
}


void ServoRunnerA::GetNowPos(uint8_t ID, uint16_t& Pos)
{  
  __innoCommandBuff__[0] = 190;
  __innoCommandBuff__[2] = ID;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Pos = *((uint16_t *)&__innoCommandBuff__);   
  }	        

}


void ServoRunnerA::GetPos(uint8_t ID, uint16_t& Pos)
{  
  __innoCommandBuff__[0] = 191;
  __innoCommandBuff__[2] = ID;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Pos = *((uint16_t *)&__innoCommandBuff__);   
  }	        

}


void ServoRunnerA::GetSpdAndTime(uint8_t ID, uint8_t& Spd, uint16_t& Time)
{  
  __innoCommandBuff__[0] = 192;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Spd = __innoCommandBuff__[0];
	  Time = *((uint16_t *)&__innoCommandBuff__[1]);        
  }	        
}


void ServoRunnerA::GetPosOffset(uint8_t ID, uint8_t& Offset)
{  
  __innoCommandBuff__[0] = 194;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Offset = __innoCommandBuff__[0];
  }	        
}




