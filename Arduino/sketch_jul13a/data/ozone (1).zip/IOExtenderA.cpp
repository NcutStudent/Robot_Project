/**
  ******************************************************************************
  * @file 		IOExtenderA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "IOExtenderA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
IOExtenderA::IOExtenderA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void IOExtenderA::High(uint8_t pin)
{
  __innoCommandBuff__[0] = 119;
  __innoCommandBuff__[2] = pin;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::Low(uint8_t pin)
{
  __innoCommandBuff__[0] = 120;
  __innoCommandBuff__[2] = pin;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::In(uint8_t BitNum, uint8_t &Value)
{
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = BitNum;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  	Value = __innoCommandBuff__[0];
}
void IOExtenderA::PulseOut(uint8_t BitNum, uint8_t Mode, uint16_t Width) 
{
  __innoCommandBuff__[0] = 113;
  __innoCommandBuff__[2] = BitNum;
  __innoCommandBuff__[3] = Mode;
  *((uint16_t *)&__innoCommandBuff__[4]) = Width;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void IOExtenderA::ReadPort(uint8_t PortNum, uint8_t &Value)
{
  __innoCommandBuff__[0] = 143;
  __innoCommandBuff__[2] = PortNum;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  	Value = __innoCommandBuff__[0];
}
void IOExtenderA::WritePort(uint8_t PortNum, uint8_t Value)
{
  __innoCommandBuff__[0] = 142;
  __innoCommandBuff__[2] = PortNum;
  __innoCommandBuff__[3] = Value;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void IOExtenderA::GetADC(uint8_t ChanNum, uint16_t &Value)
{
  __innoCommandBuff__[0] = 133;
  __innoCommandBuff__[2] = ChanNum;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  	Value = *((uint16_t *)&__innoCommandBuff__[0]);	 
}
void IOExtenderA::SetADC(uint8_t ChanNum)
{
  __innoCommandBuff__[0] = 132;
  __innoCommandBuff__[2] = ChanNum;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::GetTimer(uint16_t &Timer)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Timer = *((uint16_t *)&__innoCommandBuff__[0]);	
}
void IOExtenderA::SetTimer(uint8_t Mode, uint16_t Timer)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Mode;
  *((uint16_t *)&__innoCommandBuff__[3]) = Timer;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void IOExtenderA::TimerOff(void)
{
  __innoCommandBuff__[0] = 110;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::TimerOn(void)
{
  __innoCommandBuff__[0] = 111;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::SetDirPort(uint8_t Port, uint8_t Dir)
{
  __innoCommandBuff__[0] = 134;
  __innoCommandBuff__[2] = Port;
  __innoCommandBuff__[3] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}				  

uint8_t IOExtenderA::GetPort0LowEventStatus(void)
{
  __innoCommandBuff__[0] = 48;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort1LowEventStatus(void)
{
  __innoCommandBuff__[0] = 49;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort2LowEventStatus(void)
{
  __innoCommandBuff__[0] = 50;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort0HighEventStatus(void)
{
  __innoCommandBuff__[0] = 51;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort1HighEventStatus(void)
{
  __innoCommandBuff__[0] = 52;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort2HighEventStatus(void)
{
  __innoCommandBuff__[0] = 53;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort0ChangeEventStatus(void)
{
  __innoCommandBuff__[0] = 54;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort1ChangeEventStatus(void)
{
  __innoCommandBuff__[0] = 55;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
uint8_t IOExtenderA::GetPort2ChangeEventStatus(void)
{
  __innoCommandBuff__[0] = 56;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
//void GetPulseWidth=_LOAD_0M_T(%MID%,103,&%ARG1%,sizeof %ARG1%);

//void GetCounter=_LOAD_0M_T(%MID%,106,&%ARG1%,sizeof %ARG1%);
void IOExtenderA::CounterOff(void)
{        
  __innoCommandBuff__[0] = 107;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
//void CounterOn=_LOAD_4B_0(%MID%,108,%ARG1%,(char)(%ARG2%),(char)(%ARG2%>>8),%ARG3%);
//void PulseOut=_LOAD_WW_0(%MID%,113,(int)(%ARG1%)|((int)(%ARG2%)<<8),%ARG3%);
void IOExtenderA::PFDOff(void)
{       
  __innoCommandBuff__[0] = 114;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::PFDOn(void)
{        
  __innoCommandBuff__[0] = 115;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::SetPFD(uint16_t Freq)
{       
  __innoCommandBuff__[0] = 116;
  *((uint16_t *)&__innoCommandBuff__[2]) = Freq;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void IOExtenderA::Toggle(uint8_t Port)
{       
  __innoCommandBuff__[0] = 117;
  __innoCommandBuff__[2] = Port;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::TogglePort2(void)
{        
  __innoCommandBuff__[0] = 123;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::TogglePort1(void)
{      
  __innoCommandBuff__[0] = 124;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::TogglePort0(void)
{        
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void IOExtenderA::ReadPort2(uint8_t& data)
{
  __innoCommandBuff__[0] = 126;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  data = __innoCommandBuff__[0];
  }	        
}	
void IOExtenderA::ReadPort1(uint8_t& data)
{
  __innoCommandBuff__[0] = 127;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  data = __innoCommandBuff__[0];
  }	        
}	
void IOExtenderA::ReadPort0(uint8_t& data)
{
  __innoCommandBuff__[0] = 128;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  data = __innoCommandBuff__[0];
  }	        
}	
void IOExtenderA::WritePort2(uint8_t data)
{ 
  __innoCommandBuff__[0] = 129;
  __innoCommandBuff__[2] = data;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::WritePort1(uint8_t data)
{        
  __innoCommandBuff__[0] = 130;
  __innoCommandBuff__[2] = data;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::WritePort0(uint8_t data)
{	        
  __innoCommandBuff__[0] = 131;
  __innoCommandBuff__[2] = data;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::SetDirPort0(uint8_t Dir)
{      
  __innoCommandBuff__[0] = 135;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::SetDirPort1(uint8_t Dir)
{       
  __innoCommandBuff__[0] = 136;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::SetDirPort2(uint8_t Dir)
{ 
  __innoCommandBuff__[0] = 137;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void IOExtenderA::GetDirPort(uint8_t& Dir0, uint8_t& Dir1, uint8_t& Dir2)
{
  __innoCommandBuff__[0] = 138;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir0 = __innoCommandBuff__[0];
      Dir1 = __innoCommandBuff__[1];
      Dir2 = __innoCommandBuff__[2];
  }	        
} 
void IOExtenderA::GetDirPort0(uint8_t& Dir)
{
  __innoCommandBuff__[0] = 139;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Dir = __innoCommandBuff__[0];
  }	        
}			
void IOExtenderA::GetDirPort1(uint8_t& Dir)
{
  __innoCommandBuff__[0] = 140;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}				
void IOExtenderA::GetDirPort2(uint8_t& Dir)
{
  __innoCommandBuff__[0] = 141;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}	


