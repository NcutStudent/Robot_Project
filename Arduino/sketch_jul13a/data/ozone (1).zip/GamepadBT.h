/**
  ******************************************************************************
  * @file 		GamepadPS
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_GAMEPAD_BT
#define __INNO_GAMEPAD_BT   
#include "innotype.h" 	   
class GamepadBT
{
    private:
	uint8_t SlaveID;
	public:
	GamepadBT(uint8_t);
	void GetLXYPos(char&, char&);
	void GetRXYPos(char&, char&);
	void GetLXYPos(int8_t&, int8_t&);
	void GetRXYPos(int8_t&, int8_t&);    
	void GetL4WayValue(uint8_t&);
	void GetR4WayValue(uint8_t&);
	void GetL8WayValue(uint8_t&);
	void GetR8WayValue(uint8_t&);
	uint16_t GetKeyStatus(void);
	void GetDir4Way(uint8_t&);
	void GetDir8Way(uint8_t&);
    
	void SetStickRefreshRate(uint8_t);
	void GetStickRefreshRate(uint8_t&);
	void SetKeyRepeatFunc(uint16_t);
	void SetRepeatTime(uint8_t);
	void GetRepeatTime(uint8_t&);
	void SetRepeatRate(uint8_t);
	void GetRepeatRate(uint8_t&);
	void GetKeyRepeatFunc(uint16_t&);
	void GetAnalog(uint8_t&);
	void GetConnect(uint8_t&);
    
};
#endif



