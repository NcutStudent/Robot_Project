/**
  ******************************************************************************
  * @file 		COLORRGB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_COLORRGB
#define __INNO_COLORRGB 
#include "innotype.h"    
class ColorRGB
{
    private:
	uint8_t SlaveID;
	public:
	ColorRGB(uint8_t);
	uint8_t GetRGB(uint16_t&, uint16_t&, uint16_t&);
	uint8_t GetCRGB(uint16_t&, uint16_t&, uint16_t&, uint16_t&);
	void StartMeasure(void);
	void TurnOnLED(void);
    void LoadLED(void);
    void SetPrescalar(uint8_t);
	void TurnOffLED(void);
	void SetLEDRGB(uint8_t, uint8_t, uint8_t);
	void ScaleLED(uint8_t);
	void SetPeriod(uint8_t);
	void SetGain(uint8_t);
	void SetPrescaler(uint8_t);	

    void GetClear(uint16_t&);
    void GetBlue(uint16_t&);
    void GetGreen(uint16_t&);
    void GetRed(uint16_t&);
    void SaveCurColorVal(uint8_t);
    void SaveColorDes(uint8_t, uint8_t, uint8_t, uint8_t);
    void SaveColorVal(uint8_t, uint16_t, uint16_t, uint16_t, uint16_t);
    void SaveColorInfo(uint8_t, uint8_t, uint8_t, uint8_t, uint16_t, uint16_t, uint16_t, uint16_t);
    void GetColorVal(uint8_t, uint16_t&, uint16_t&, uint16_t&, uint16_t&);
    void GetColorDes(uint8_t, uint8_t&, uint8_t&, uint8_t&);
    void MatchColorDesAll(uint8_t, uint8_t, uint8_t);
    void MatchColorDesIndex(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
    void MatchCurColorAll(void);
    void MatchCurColorIndex(uint8_t, uint8_t);
    void MatchCurColorRGBAll(void);
    void MatchCurColorRGBIndex(uint8_t, uint8_t);
    void GetMatchNum(uint8_t&);
    void GetMatchNeighborNum(uint8_t&, uint8_t&, uint8_t&);
    uint8_t GetMatchStatus(void);
    void GetMatchDiff(int16_t&, int16_t&, int16_t&, int16_t&);
    void GetMatchDiffAll(uint16_t&);
    void GetLEDStatus(uint8_t&);
    void GetPeriod(uint8_t&);
    void GetGain(uint8_t&);
    void GetPrescalar(uint8_t&);
    void GetLEDRGB(uint8_t&, uint8_t&, uint8_t&);
    void SetMatchMaxDiff(uint16_t);
    void GetMatchMaxDiff(uint16_t&);    
};
#endif



