/**
  ******************************************************************************
  * @file 		JoyStick2A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_JOYSTICK_2A
#define __INNO_JOYSTICK_2A	
#include "innotype.h"
class JoyStick2A
{
    private:
	uint8_t SlaveID;
	public:
	JoyStick2A(uint8_t);
	void GetXY(char&, char&);
	void GetXY(int8_t&, int8_t&);    
	uint8_t Get4WayStatus(void);
	uint8_t Get8WayStatus(void);
	uint8_t GetButtonStatus(void);
    void StartCalibration(void);
	void GetPolarBinaryRadian(uint8_t&, uint16_t&);
    
    
	void SetCalibrationX(uint16_t, uint16_t, uint16_t);
	void GetCalibrationX(uint16_t&, uint16_t&, uint16_t&);
	void SetCalibrationY(uint16_t, uint16_t, uint16_t);
	void GetCalibrationY(uint16_t&, uint16_t&, uint16_t&);
	void RestoreSettings(void);
	void SetStickDeadZone(uint8_t, uint8_t);
	void GetStickDeadZone(uint8_t&, uint8_t&);
	void SetRadiusDeadZone(uint8_t);
	void GetRadiusDeadZone(uint8_t&);
	void SetXYSaturation(uint8_t, uint8_t);
	void GetXYSaturation(uint8_t&, uint8_t&);
	void SetRadiusSaturation(uint8_t);
	void GetRadiusSaturation(uint8_t&);
	void SetXYRes(uint8_t, uint8_t);
	void GetXYRes(uint8_t&, uint8_t&);
	void SetRadiusRes(uint8_t);
	void GetRadiusRes(uint8_t&);
	void SetRadianRes(uint16_t);
	void GetRadianRes(uint16_t&);
	void ButtonRepeatFunc(uint8_t);
	void SetRepeatTime(uint8_t);
	void GetRepeatTime(uint8_t&);
	void SetRepeatRate(uint8_t);
	void GetRepeatRate(uint8_t&);
	void SetEventRefreshRate(uint8_t);
	void GetEventRefreshRate(uint8_t&);
    void GetPolarRadian(float&, float&);
    
};
#endif



