/**
  ******************************************************************************
  * @file 		Accelerometer3A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "Accelerometer3A.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
Accelerometer3A::Accelerometer3A(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void Accelerometer3A::GetXYZForce(int16_t &XForce, int16_t &YForce, int16_t &ZForce)
{
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 7;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  XForce = *((int16_t *)&__innoCommandBuff__);
	  YForce = *((int16_t *)&__innoCommandBuff__[2]);
	  ZForce = *((int16_t *)&__innoCommandBuff__[4]);
  }	  	        	  
}
void Accelerometer3A::GetAngle2D(uint16_t &Angle)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B6;
	if(*ptr != 'C') return;
#endif		
  __innoCommandBuff__[0] = 95;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Angle = *((uint16_t *)&__innoCommandBuff__);
}
void Accelerometer3A::SaveAngle2D(uint8_t no, uint16_t Angle)
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = no;
  *((uint16_t *)&__innoCommandBuff__[3]) = Angle;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void Accelerometer3A::GetDevAngle2D(uint8_t no, int16_t &Angle)
{
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = no;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
    Angle = *((int16_t *)&__innoCommandBuff__);
}
void Accelerometer3A::SetMode(uint8_t Mode)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void Accelerometer3A::SetAxis2D(uint8_t Axis2D)
{
  __innoCommandBuff__[0] = 170;
  __innoCommandBuff__[2] = Axis2D;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void Accelerometer3A::GetXADVal(uint16_t &ADVal)
{
  __innoCommandBuff__[0] = 162;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	ADVal = *((uint16_t *)&__innoCommandBuff__);
}
void Accelerometer3A::GetYADVal(uint16_t &ADVal)
{
  __innoCommandBuff__[0] = 163;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	ADVal = *((uint16_t *)&__innoCommandBuff__);
}
void Accelerometer3A::GetZADVal(uint16_t &ADVal)
{
  __innoCommandBuff__[0] = 164;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	ADVal = *((uint16_t *)&__innoCommandBuff__);
}
void Accelerometer3A::GetAngle3D (uint16_t &Angle1, uint8_t &Angle2)
{
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Angle1 = *((uint16_t *)&__innoCommandBuff__);   
	  Angle2 = __innoCommandBuff__[2];
  }	        
}
void Accelerometer3A::SetRefreshFreq(uint8_t RefreshFreq)
{
  __innoCommandBuff__[0] = 98;
  __innoCommandBuff__[2] = RefreshFreq;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
uint8_t Accelerometer3A::GetRefreshStatus(void)
{
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0];
  return  0;
}


void Accelerometer3A::GetMode(uint8_t& Mode)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Mode = __innoCommandBuff__[0];   
  }	
}    
void Accelerometer3A::GetXForce(int16_t& Force)
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((int16_t *)&__innoCommandBuff__[0]);
  }	
}    
void Accelerometer3A::GetYForce(int16_t& Force)
{
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((int16_t *)&__innoCommandBuff__[0]);
  }	
}    
void Accelerometer3A::GetZForce(int16_t& Force)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((int16_t *)&__innoCommandBuff__[0]);
  }	
}    

void Accelerometer3A::GetForce2D(uint16_t& Force, uint16_t& Angle)
{
  __innoCommandBuff__[0] = 94;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((uint16_t *)&__innoCommandBuff__);   
	  Angle = *((uint16_t *)&__innoCommandBuff__[2]); 
  }	
}    
void Accelerometer3A::GetForce3D(uint16_t& Force, uint16_t& Angle1, uint8_t& Angle2)
{
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((uint16_t *)&__innoCommandBuff__);   
      Angle1 = *((uint16_t *)&__innoCommandBuff__[2]);
	  Angle2 = __innoCommandBuff__[4];
  }	
}    
void Accelerometer3A::GetRefreshFreq(uint8_t& Freq)
{
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Freq = __innoCommandBuff__[0];
  }	
}    
void Accelerometer3A::SaveCurrAngle2D(uint8_t Number)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Number;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
}    

void Accelerometer3A::LoadAngle2D(uint8_t Number, uint16_t& Angle)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Angle = *((uint16_t *)&__innoCommandBuff__);
  }	
}    

void Accelerometer3A::SetDevAngleLimit2D(uint8_t Limit)
{
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
}    
void Accelerometer3A::GetDevAngleLimit2D(uint8_t& Limit)
{
  __innoCommandBuff__[0] = 108;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Limit = __innoCommandBuff__[0];
  }	 
}    
void Accelerometer3A::SetDevAngleNum2D(uint8_t Number)
{
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = Number;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
}    
void Accelerometer3A::GetDevAngleNum2D(uint8_t&Number)
{
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Number = __innoCommandBuff__[0];
  }	
}    

uint8_t Accelerometer3A::GetDevAngleLimitStatus2D(void)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);
  }	
  return 0;

}    

void Accelerometer3A::SaveCurrAngle3D(uint8_t Number)
{
  __innoCommandBuff__[0] = 114;
  __innoCommandBuff__[2] = Number;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
}    
void Accelerometer3A::SaveAngle3D(uint8_t Number, uint16_t Angle1, uint8_t Angle2)
{
  __innoCommandBuff__[0] = 115;
  __innoCommandBuff__[2] = Number;
  __innoCommandBuff__[3] = Angle2;
  *((uint16_t *)&__innoCommandBuff__[4]) = Angle1;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);  
}    
void Accelerometer3A::LoadAngle3D(uint8_t Number, uint16_t& Angle1, uint8_t& Angle2)
{
  __innoCommandBuff__[0] = 116;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Angle1 = *((uint16_t *)&__innoCommandBuff__);   
	  Angle2 = __innoCommandBuff__[2];
  }	
}     
void Accelerometer3A::GetDevAngle3D(uint8_t Number, int16_t& arg1, int16_t& arg2)
{
  __innoCommandBuff__[0] = 117;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  arg1 = *((int16_t *)&__innoCommandBuff__);   
	  arg2 = *((int16_t *)&__innoCommandBuff__[2]);
  }	
}     
void Accelerometer3A::SetXForceLimit(uint8_t Number, uint16_t Limit)
{
  __innoCommandBuff__[0] = 125;
  __innoCommandBuff__[2] = Number;
  *((int16_t *)&__innoCommandBuff__[3]) = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);  
}     
void Accelerometer3A::GetXForceLimit(uint8_t Number, uint16_t& Limit)
{
  __innoCommandBuff__[0] = 126;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Limit = *((uint16_t *)&__innoCommandBuff__);   
  }	
}     
uint8_t Accelerometer3A::GetXForceLimitStatus(void)
{
  __innoCommandBuff__[0] = 127;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);   
  }	
  return 0;
}     
void Accelerometer3A::SetYForceLimit(uint8_t Number, uint16_t Limit)
{
  __innoCommandBuff__[0] = 130;
  __innoCommandBuff__[2] = Number;
  *((int16_t *)&__innoCommandBuff__[3]) = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);   
}     
void Accelerometer3A::GetYForceLimit(uint8_t Number, uint16_t& Limit)
{
  __innoCommandBuff__[0] = 131;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Limit = *((uint16_t *)&__innoCommandBuff__);   
  }  
}     
uint8_t Accelerometer3A::GetYForceLimitStatus(void)
{
  __innoCommandBuff__[0] = 132;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);   
  }	
  return 0;  
}     
void Accelerometer3A::SetZForceLimit(uint8_t Number, uint16_t Limit)
{
  __innoCommandBuff__[0] = 135;
  __innoCommandBuff__[2] = Number;
  *((int16_t *)&__innoCommandBuff__[3]) = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);   
}      
void Accelerometer3A::GetZForceLimit(uint8_t Number, uint16_t& Limit)
{
  __innoCommandBuff__[0] = 136;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Limit = *((uint16_t *)&__innoCommandBuff__);   
  }  
}     
uint8_t Accelerometer3A::GetZForceLimitStatus(void)
{
  __innoCommandBuff__[0] = 137;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);
  }	
  return 0;
}     
void Accelerometer3A::SetForceLimit2D(uint8_t Number, uint16_t Limit)
{

  __innoCommandBuff__[0] = 140;
  __innoCommandBuff__[2] = Number;
  *((uint16_t *)&__innoCommandBuff__[3]) = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);  
}      
void Accelerometer3A::GetForceLimit2D(uint8_t Number, uint16_t& Limit)
{
  __innoCommandBuff__[0] = 141;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Limit = *((uint16_t *)&__innoCommandBuff__);   
  }	
}     
uint8_t Accelerometer3A::GetForceLimit2DStatus(void)
{
  __innoCommandBuff__[0] = 142;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);
  }	
  return 0;  
}     
void Accelerometer3A::SetForceLimit3D(uint8_t Number, uint16_t Limit)
{
  __innoCommandBuff__[0] = 145;
  __innoCommandBuff__[2] = Number;
  *((uint16_t *)&__innoCommandBuff__[3]) = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);  
}      
void Accelerometer3A::GetForceLimit3D(uint8_t Number, uint16_t& Limit)
{
  __innoCommandBuff__[0] = 146;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Limit = *((uint16_t *)&__innoCommandBuff__);   
  }	
}     
uint8_t Accelerometer3A::GetForceLimit3DStatus(void)
{
  __innoCommandBuff__[0] = 147;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return(__innoCommandBuff__[0]);
  }	
  return 0;
}     
void Accelerometer3A::GetMaxXForce(int16_t& Force)
{
  __innoCommandBuff__[0] = 150;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((int16_t *)&__innoCommandBuff__);   
  }	
}      
void Accelerometer3A::GetMaxYForce(int16_t& Force)
{
  __innoCommandBuff__[0] = 151;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	 Force = *((int16_t *)&__innoCommandBuff__);  
  }	
}         
void Accelerometer3A::GetMaxZForce(int16_t& Force)
{
  __innoCommandBuff__[0] = 152;
  __innoNumByteToRead__ =  3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((uint16_t *)&__innoCommandBuff__);  
  }	
}         
void Accelerometer3A::GetMaxForce2D(int16_t& Force, uint16_t& Angle)
{
  __innoCommandBuff__[0] = 153;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((int16_t *)&__innoCommandBuff__);   
	  Angle = *((uint16_t *)&__innoCommandBuff__[2]); ;
  }	

}        
void Accelerometer3A::GetMaxForce3D(int16_t& Force, uint16_t& Angle1, uint8_t& Angle2)
{
  __innoCommandBuff__[0] = 154;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Force = *((int16_t *)&__innoCommandBuff__);   
	  Angle1 = *((uint16_t *)&__innoCommandBuff__[2]); 
	  Angle2 = __innoCommandBuff__[4]; 
  }	
}      
void Accelerometer3A::ClrMaxXForce(void)
{
  __innoCommandBuff__[0] = 155;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}     
void Accelerometer3A::ClrMaxYForce(void)
{
  __innoCommandBuff__[0] = 156;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}      
void Accelerometer3A::ClrMaxZForce(void)
{
  __innoCommandBuff__[0] = 157;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}      
void Accelerometer3A::ClrMaxForce2D(void)
{
  __innoCommandBuff__[0] = 158;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}      
void Accelerometer3A::ClrMaxForce3D(void)
{
  __innoCommandBuff__[0] = 159;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}      
void Accelerometer3A::SaveCalVal(uint8_t mode, uint16_t X0G, uint16_t X1G, uint16_t X_1G, 
                                               uint16_t Y0G, uint16_t Y1G, uint16_t Y_1G, 
                                               uint16_t Z0G, uint16_t Z1G, uint16_t Z_1G)
{
  __innoCommandBuff__[0] = 165;
  __innoCommandBuff__[2] = mode;
  *((uint16_t *)&__innoCommandBuff__[3]) = X0G;    
  *((uint16_t *)&__innoCommandBuff__[5]) = X1G;
  *((uint16_t *)&__innoCommandBuff__[7]) = X_1G;    
  *((uint16_t *)&__innoCommandBuff__[9]) = Y0G;
  *((uint16_t *)&__innoCommandBuff__[11]) = Y1G;
  *((uint16_t *)&__innoCommandBuff__[13]) = Y_1G;
  *((uint16_t *)&__innoCommandBuff__[15]) = Z0G;
  *((uint16_t *)&__innoCommandBuff__[17]) = Z1G;
  *((uint16_t *)&__innoCommandBuff__[19]) = Z_1G;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 21);  
}     
void Accelerometer3A::LoadCalVal(uint8_t mode, uint16_t& X0G, uint16_t& X1G, uint16_t& X_1G, 
                                               uint16_t& Y0G, uint16_t& Y1G, uint16_t& Y_1G, 
                                               uint16_t& Z0G, uint16_t& Z1G, uint16_t& Z_1G)
{
  __innoCommandBuff__[0] = 166;
  __innoCommandBuff__[2] = mode;    
  __innoNumByteToRead__ = 19;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
    X0G = *((uint16_t *)&__innoCommandBuff__[0]);    
    X1G = *((uint16_t *)&__innoCommandBuff__[2]); 
    X_1G = *((uint16_t *)&__innoCommandBuff__[4]);     
    Y0G = *((uint16_t *)&__innoCommandBuff__[6]); 
    Y1G = *((uint16_t *)&__innoCommandBuff__[8]);
    Y_1G = *((uint16_t *)&__innoCommandBuff__[10]);
    Z0G = *((uint16_t *)&__innoCommandBuff__[12]);
    Z1G = *((uint16_t *)&__innoCommandBuff__[14]);
    Z_1G = *((uint16_t *)&__innoCommandBuff__[16]);    
  }	
}     
void Accelerometer3A::RestoreCalVal(void)
{
  __innoCommandBuff__[0] = 169;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  
}
void Accelerometer3A::GetAxis2D(uint8_t& Axis)
{
  __innoCommandBuff__[0] = 171;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	 Axis = __innoCommandBuff__[0];
  }	
}       
