/**
  ******************************************************************************
  * @file 		GamepadPS
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "GamepadPs.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
GamepadPS::GamepadPS(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B7;
	if((mySlaveID & 1) && (*ptr != 'H')) return;
#endif	
  InitArmCommander();
}
void GamepadPS::GetLXYPos(char &LXPos, char &LYPos)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  LXPos = (int8_t)__innoCommandBuff__[0];
	  LYPos = (int8_t)__innoCommandBuff__[1];
  }	        	  	
}
void GamepadPS::GetLXYPos(int8_t &LXPos, int8_t &LYPos)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  LXPos = (int8_t)__innoCommandBuff__[0];
	  LYPos = (int8_t)__innoCommandBuff__[1];
  }	        	  	
}
void GamepadPS::GetLXYPos(int16_t &LXPos, int16_t &LYPos)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  LXPos = (int8_t)__innoCommandBuff__[0];
	  LYPos = (int8_t)__innoCommandBuff__[1];
  }	        	  	
}
void GamepadPS::GetRXYPos(char &RXPos, char &RYPos)
{
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	RXPos = (int8_t)__innoCommandBuff__[0];
  	RYPos = (int8_t)__innoCommandBuff__[1];
  }		     
} 
void GamepadPS::GetRXYPos(int8_t &RXPos, int8_t &RYPos)
{
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	RXPos = (int8_t)__innoCommandBuff__[0];
  	RYPos = (int8_t)__innoCommandBuff__[1];
  }		     
}
void GamepadPS::GetRXYPos(int16_t &RXPos, int16_t &RYPos)
{
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	RXPos = (int8_t)__innoCommandBuff__[0];
  	RYPos = (int8_t)__innoCommandBuff__[1];
  }		     
}
void GamepadPS::GetL4WayValue(uint8_t &Way)
{
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Way = __innoCommandBuff__[0];
}
void GamepadPS::GetR4WayValue(uint8_t &Way)
{
  __innoCommandBuff__[0] = 116;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Way = __innoCommandBuff__[0];
}
void GamepadPS::GetL8WayValue(uint8_t &Way)
{
  __innoCommandBuff__[0] = 117;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Way = __innoCommandBuff__[0];
}
void GamepadPS::GetR8WayValue(uint8_t &Way)
{
  __innoCommandBuff__[0] = 118;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__)) 
  	Way = __innoCommandBuff__[0];
}
uint16_t GamepadPS::GetKeyStatus(void)
{
  __innoCommandBuff__[0] = 138;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__)) return(*((uint16_t *)&__innoCommandBuff__[0]));
  else                                                          return 0;
}
void GamepadPS::GetDir4Way(uint8_t &Dir4Way)
{
  __innoCommandBuff__[0] = 141;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    Dir4Way = __innoCommandBuff__[0];
}
void GamepadPS::GetDir4Way(int16_t &Dir4Way)
{
  __innoCommandBuff__[0] = 141;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    Dir4Way = __innoCommandBuff__[0];
}
void GamepadPS::GetDir8Way(uint8_t &Dir8Way)
{
  __innoCommandBuff__[0] = 142;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Dir8Way = __innoCommandBuff__[0];
}
void GamepadPS::StartVib(uint8_t Time, uint8_t Level)
{
  __innoCommandBuff__[0] = 152;
  __innoCommandBuff__[2] = Time;
  __innoCommandBuff__[3] = Level;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::StopVib(void)
{
  __innoCommandBuff__[0] = 153;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void GamepadPS::StickCalibration(void)
{
  __innoCommandBuff__[0] = 155;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}	

void GamepadPS::SetCalibrationLX(uint8_t Min, uint8_t Cen, uint8_t Max)
{     
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = Min;
  __innoCommandBuff__[3] = Cen;
  __innoCommandBuff__[4] = Max;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}

void GamepadPS::GetCalibrationLX(uint8_t& Min, uint8_t& Cen, uint8_t& Max)
{
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Min = __innoCommandBuff__[0];  
	  Cen = __innoCommandBuff__[1];
      Max = __innoCommandBuff__[2]; 
  }	        
}
void GamepadPS::SetCalibrationLY(uint8_t Min, uint8_t Cen, uint8_t Max)
{       
  __innoCommandBuff__[0] = 92;
  __innoCommandBuff__[2] = Min;
  __innoCommandBuff__[3] = Cen;
  __innoCommandBuff__[4] = Max;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void GamepadPS::GetCalibrationLY(uint8_t& Min, uint8_t& Cen, uint8_t& Max)
{
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Min = __innoCommandBuff__[0];  
	  Cen = __innoCommandBuff__[1];
      Max = __innoCommandBuff__[2]; 
  }	
}
void GamepadPS::SetCalibrationRX(uint8_t Min, uint8_t Cen, uint8_t Max)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = Min;
  __innoCommandBuff__[3] = Cen;
  __innoCommandBuff__[4] = Max;   
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void GamepadPS::GetCalibrationRX(uint8_t& Min, uint8_t& Cen, uint8_t& Max)
{
  __innoCommandBuff__[0] = 95;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Min = __innoCommandBuff__[0];  
	  Cen = __innoCommandBuff__[1];
      Max = __innoCommandBuff__[2]; 
  }	        
}
void GamepadPS::SetCalibrationRY(uint8_t Min, uint8_t Cen, uint8_t Max)
{        
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = Min;
  __innoCommandBuff__[3] = Cen;
  __innoCommandBuff__[4] = Max;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void GamepadPS::GetCalibrationRY(uint8_t& Min, uint8_t& Cen, uint8_t& Max)
{
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Min = __innoCommandBuff__[0];  
	  Cen = __innoCommandBuff__[1];
      Max = __innoCommandBuff__[2]; 
  }	        
}
void GamepadPS::RestoreSettings(void)
{      
  __innoCommandBuff__[0] = 98;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void GamepadPS::SetLStickDeadZone(uint8_t DZx, uint8_t DZy)
{     
  __innoCommandBuff__[0] = 99;
  __innoCommandBuff__[2] = DZx;
  __innoCommandBuff__[3] = DZy;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::GetLStickDeadZone(uint8_t& DZx, uint8_t& DZy)
{
  __innoCommandBuff__[0] = 100;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DZx = __innoCommandBuff__[0];   
	  DZy = __innoCommandBuff__[1];
  }	 
}
void GamepadPS::SetRStickDeadZone(uint8_t DZx, uint8_t DZy)
{
  __innoCommandBuff__[0] = 101;
  __innoCommandBuff__[2] = DZx;
  __innoCommandBuff__[3] = DZy;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::GetRStickDeadZone(uint8_t& DZx, uint8_t& DZy)
{
  __innoCommandBuff__[0] = 102;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DZx = __innoCommandBuff__[0];
	  DZy = __innoCommandBuff__[1];
  }	        
}
void GamepadPS::SetLStickSaturation(uint8_t Satx, uint8_t Saty)
{        
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Satx;
  __innoCommandBuff__[3] = Saty;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::GetLStickSaturation(uint8_t& Satx, uint8_t& Saty)
{
  __innoCommandBuff__[0] = 104;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Satx = __innoCommandBuff__[0];
	  Saty = __innoCommandBuff__[1];
  }	        

}
void GamepadPS::SetRStickSaturation(uint8_t Satx, uint8_t Saty)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Satx;
  __innoCommandBuff__[3] = Saty;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void GamepadPS::GetRStickSaturation(uint8_t& Satx, uint8_t& Saty)
{
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Satx = __innoCommandBuff__[0];
	  Saty = __innoCommandBuff__[1];
  }	        
}
void GamepadPS::SetLStickRes(uint8_t Resx, uint8_t Resy)
{   
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = Resx;
  __innoCommandBuff__[3] = Resy;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::GetLStickRes(uint8_t& Resx, uint8_t& Resy)
{
  __innoCommandBuff__[0] = 108;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Resx = __innoCommandBuff__[0];   
	  Resy = __innoCommandBuff__[1];
  }	  
}
void GamepadPS::SetRStickRes(uint8_t Resx, uint8_t Resy)
{        
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = Resx;
  __innoCommandBuff__[3] = Resy;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::GetRStickRes(uint8_t& Resx, uint8_t& Resy)
{
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Resx = __innoCommandBuff__[0];
	  Resy = __innoCommandBuff__[1];
  }	        
}
void GamepadPS::SetStickRefreshRate(uint8_t Rate)
{   
  __innoCommandBuff__[0] = 111;
  __innoCommandBuff__[2] = Rate;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void GamepadPS::GetStickRefreshRate(uint8_t& Rate)
{
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Rate = __innoCommandBuff__[0];
  }	        
}
void GamepadPS::SetKeyRepeatFunc(uint16_t KeyID)
{    
  __innoCommandBuff__[0] = 133;
  *((uint16_t *)&__innoCommandBuff__[2]) = KeyID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void GamepadPS::SetRepeatTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 134;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void GamepadPS::GetRepeatTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 135;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	        
}
void GamepadPS::SetRepeatRate(uint8_t Rate)
{    
  __innoCommandBuff__[0] = 136;
  __innoCommandBuff__[2] = Rate;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void GamepadPS::GetRepeatRate(uint8_t& Rate)
{
  __innoCommandBuff__[0] = 137;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Rate = __innoCommandBuff__[0];
  }	        
}
void GamepadPS::GetKeyRepeatFunc(uint16_t& KeyID)
{
  __innoCommandBuff__[0] = 147;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  KeyID = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}
void GamepadPS::GetAnalog(uint8_t& Analog)
{
  __innoCommandBuff__[0] = 150;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Analog = __innoCommandBuff__[0];
  }	        
}
void GamepadPS::GetConnect(uint8_t& Connect)
{
  __innoCommandBuff__[0] = 151;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Connect = __innoCommandBuff__[0];
  }	        
}
void GamepadPS::GetVibStatus(uint8_t& Status, uint8_t& Time, uint8_t& Level)
{
  __innoCommandBuff__[0] = 154;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Status = __innoCommandBuff__[0]; 
	  Time = __innoCommandBuff__[1];
      Level = __innoCommandBuff__[2];
  }	        
}
void GamepadPS::SetAnalog(uint8_t Analog)
{  
  __innoCommandBuff__[0] = 158;
  __innoCommandBuff__[2] = Analog;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

