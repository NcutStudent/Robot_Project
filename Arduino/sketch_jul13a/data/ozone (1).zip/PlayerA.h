/**
  ******************************************************************************
  * @file 		PlayerA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_PLAYER_A
#define __INNO_PLAYER_A	 
#include "innotype.h" 
class PlayerA
{
    private:
	uint8_t SlaveID;
	public:
	PlayerA(uint8_t);
	void Play(void);
	void Pause(void);
	void Stop(void);
	void Forward(void);
	void Backward(void);
	void SetPlayNum(uint16_t);
	void VolUp(void);
	void VolDown(void);
	void Mute(uint8_t);
	void AnalSD(void);
	void SetVol(uint8_t);
	void SetRepeat(uint8_t);
	void SetEQ(uint8_t EQ);
	void GetTotalNum(uint16_t&);
	uint8_t GetSDStatus(void);
    

	void GetVol(uint8_t&);
	void GetPlayTime(uint8_t&, uint8_t&);
	void GetRepeat(uint8_t&);
	void GetEQ(uint8_t&);
	void LoadID3(uint8_t);
	void GetID3Status(uint8_t&, uint8_t&);
	void GetID3Bytes(uint8_t&);
	void GetID3Info(uint8_t Num, uint8_t& Byte0, uint8_t& Byte1, uint8_t& Byte2, uint8_t& Byte3, 
                                 uint8_t& Byte4, uint8_t& Byte5, uint8_t& Byte6, uint8_t& Byte7);
	void LoadFileName(void);
	uint8_t GetFileStatus(void);
	void GetFileNameBytes(uint8_t&);
	void GetFileName(uint8_t Num, uint8_t& Byte0, uint8_t& Byte1, uint8_t& Byte2, uint8_t& Byte3, 
                                  uint8_t& Byte4, uint8_t& Byte5, uint8_t& Byte6, uint8_t& Byte7);
	void GetPlayNum(uint16_t&);
	void SetAutoPlay(uint8_t);
	void GetAutoPlay(uint8_t&);    
};
#endif



