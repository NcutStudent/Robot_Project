/**
  ******************************************************************************
  * @file 		SonarB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	06/09/2014
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "SonarB.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
SonarB::SonarB(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void SonarB::Ranging(void)
{
  __innoCommandBuff__[0] = 88;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void SonarB::RepeatRanging(void)
{
  __innoCommandBuff__[0] = 89;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void SonarB::StopRanging(void)
{
  __innoCommandBuff__[0] = 90;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t SonarB::GetDistance(uint8_t Type, uint16_t &Distance)
{
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Type;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
  	Distance  = *((uint16_t *)&__innoCommandBuff__[1]);
    return __innoCommandBuff__[0];
  }
  return 0;
}

void SonarB::SetRangingTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarB::GetRangingTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	 
}
void SonarB::SetRepeatCount(uint8_t Count)
{
  __innoCommandBuff__[0] = 110;
  __innoCommandBuff__[2] = Count;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarB::SetRepeatTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 111;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void SonarB::GetRepeatCount(uint8_t& Count)
{
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Count = __innoCommandBuff__[0];
  }	 
}
void SonarB::GetRepeatTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	 
}
void SonarB::GetADValue(uint8_t Ch, uint16_t& Value)
{
  __innoCommandBuff__[0] = 120;
  __innoCommandBuff__[2] = Ch;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
  	Value  = *((uint16_t *)&__innoCommandBuff__[1]);
  }
  return;
}
void SonarB::SetMode(uint8_t Mode)
{
  __innoCommandBuff__[0] = 121;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}



