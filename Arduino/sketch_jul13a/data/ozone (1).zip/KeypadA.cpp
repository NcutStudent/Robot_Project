/**
  ******************************************************************************
  * @file 		KeypadA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "KeypadA.h"    
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
KeypadA::KeypadA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void KeypadA::ClearKeyBuffer(void)
{
  __innoCommandBuff__[0] = 101;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t KeypadA::GetKeyID(uint8_t &KeyID)
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  	KeyID = __innoCommandBuff__[1];
    return __innoCommandBuff__[0];
  }
  return 0;
}
void KeypadA::SetKeypadMode(uint8_t Mode)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void KeypadA::GetKeypadMode(uint8_t &Mode)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Mode = __innoCommandBuff__[0];
}

void KeypadA::SetCustomTable(uint8_t *ptr)
{        
  __innoCommandBuff__[0] = 91;
  for(int i = 0 ; i < 16 ; i++)  
    __innoCommandBuff__[2+i] = *ptr++;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 20);
  
}  
void KeypadA::GetCustomTable(uint8_t *ptr)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 17;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
      for(int i = 0 ; i < 16 ; i++)  
        *ptr++ = __innoCommandBuff__[i];
  }	        
}  

void KeypadA::LoadCustomTable(uint8_t Index)
{        
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = Index;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
  
}  

void KeypadA::SaveCustomTable(uint8_t Index)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = Index;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
}  

void KeypadA::SetRepeatTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Time;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
  
}  

void KeypadA::GetRepeatTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	          
}  

void KeypadA::SetRepeatRate(uint8_t Rate)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Rate;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
  
}  

void KeypadA::GetRepeatRate(uint8_t& Rate)
{
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Rate = __innoCommandBuff__[0];
  }	        
  
}  

void KeypadA::SetDebounceTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 99;
  __innoCommandBuff__[2] = Time;    	 
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);  
  
}  

void KeypadA::GetDebounceTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 100;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	        
  
}  

void KeypadA::GetCustomTableIndex(uint8_t& Index)
{
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Index = __innoCommandBuff__[0];
  }	        
 
}  


