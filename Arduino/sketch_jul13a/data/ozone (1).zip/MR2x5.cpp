/**
  ******************************************************************************
  * @file 		MR2X5
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "MR2X5.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
MR2X5::MR2X5(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
} 
void MR2X5::ForwardA(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::ForwardB(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}  
void MR2X5::ForwardAB(uint8_t DutyCycleA, uint8_t DutyCycleB)
{
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = DutyCycleA;
  __innoCommandBuff__[3] = DutyCycleB;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X5::BackwardA(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 92;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::BackwardB(uint8_t DutyCycle)
{
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = DutyCycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}	
void MR2X5::BackwardAB(uint8_t DutyCycleA, uint8_t DutyCycleB)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = DutyCycleA;
  __innoCommandBuff__[3] = DutyCycleB;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X5::BrakeA(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X5::BrakeB(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X5::BrakeDual(void)
{
  __innoCommandBuff__[0] = 101;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}    	
void MR2X5::StopA(void)
{
  __innoCommandBuff__[0] = 96;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X5::StopB(void)
{
  __innoCommandBuff__[0] = 97;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X5::StopDual(void)
{
  __innoCommandBuff__[0] = 98;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MR2X5::SetDirAB(uint8_t DirA, uint8_t DirB)
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = DirA;
  __innoCommandBuff__[3] = DirB;	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X5::SetVelAB(int16_t DutyCycleA, int16_t DutyCycleB)
{
  __innoCommandBuff__[0] = 118;
  *((int16_t *)&__innoCommandBuff__[2]) = DutyCycleA;
  *((int16_t *)&__innoCommandBuff__[4]) = DutyCycleB;	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void MR2X5::GetCurr(uint16_t &CurrA, uint16_t &CurrB) 
{
  __innoCommandBuff__[0] = 132;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  	CurrA = *((uint16_t *)&__innoCommandBuff__[0]);	  	
  	CurrB = *((uint16_t *)&__innoCommandBuff__[2]);
  }		  	  
}

void MR2X5::SetCurrMode(uint8_t Mode, uint8_t Time, uint16_t Curr)
{
  __innoCommandBuff__[0] = 133;
  __innoCommandBuff__[2] = Mode;
  __innoCommandBuff__[3] = Time;
  __innoCommandBuff__[4] = Curr;
  __innoCommandBuff__[5] = Curr>>8;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);	  	
}

uint8_t MR2X5::GetBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}     
void MR2X5::ClrBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 124;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);	  	
}
uint8_t MR2X5::GetFaultStatus(void)
{
  __innoCommandBuff__[0] = 127;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}    
void MR2X5::EnFaultStop(void)
{
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X5::DisFaultStop(void)
{
  __innoCommandBuff__[0] = 126;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X5::ClearFaultStatus(void)
{
  __innoCommandBuff__[0] = 128;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MR2X5::RestoreStatus(void)
{
  __innoCommandBuff__[0] = 131;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
	

void MR2X5::ForwardDual(uint8_t Dutycycle)
{        
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = Dutycycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::BackwardDual(uint8_t Dutycycle)
{       
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Dutycycle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::SetDirA(uint8_t Dir)
{  	        
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::SetDirB(uint8_t Dir)
{        
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::SetDirDual(uint8_t Dir)
{        
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::SetDCA(uint8_t Spd)
{          
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::SetDCB(uint8_t Spd)
{      
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::SetDCAB(uint8_t SpdA, uint8_t SpdB)
{     
  __innoCommandBuff__[0] = 108;
  __innoCommandBuff__[2] = SpdA;
  __innoCommandBuff__[3] = SpdB;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MR2X5::SetDCDual(uint8_t Spd)
{        
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = Spd;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MR2X5::GetDCA(uint8_t& Spd)
{  
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Spd = __innoCommandBuff__[0];
  }	        
}
void MR2X5::GetDCB(uint8_t& Spd)
{  
  __innoCommandBuff__[0] = 111;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Spd = __innoCommandBuff__[0];
  }	        
}
void MR2X5::GetDirA(uint8_t& Dir)
{  
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}
void MR2X5::GetDirB(uint8_t& Dir)
{  
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[0];
  }	        
}
void MR2X5::GetDCAB(uint8_t& SpdA, uint8_t& SpdB)
{  
  __innoCommandBuff__[0] = 114;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  SpdA = __innoCommandBuff__[0];
	  SpdB = __innoCommandBuff__[1];
  }	        

}
void MR2X5::GetDirAB(uint8_t& DirA, uint8_t& DirB)
{  
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DirA = __innoCommandBuff__[0];
	  DirB = __innoCommandBuff__[1];
  }	        

}
void MR2X5::SetVelA(int16_t Vel)
{  
  __innoCommandBuff__[0] = 116;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);        
}
void MR2X5::SetVelB(int16_t Vel)
{  
  __innoCommandBuff__[0] = 117;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);       
}
void MR2X5::SetVelDual(int16_t Vel)
{  
  __innoCommandBuff__[0] = 119;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);        
}
void MR2X5::GetVelA(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 120;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }	        
}
void MR2X5::GetVelB(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 121;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }
}
void MR2X5::GetVelAB(int16_t& VelA, int16_t& VelB)
{  
  __innoCommandBuff__[0] = 122;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  VelA = *((int16_t *)&__innoCommandBuff__[0]);   
	  VelB = *((int16_t *)&__innoCommandBuff__[2]); 
  }	        
}
void MR2X5::GetCurrMode(uint8_t& Mode, uint8_t& Time, uint16_t& Curr)
{  
  __innoCommandBuff__[0] = 134;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Mode = __innoCommandBuff__[0];   
	  Time = __innoCommandBuff__[1];
      Curr = *((uint16_t *)&__innoCommandBuff__[2]);  
  }	        
}   


