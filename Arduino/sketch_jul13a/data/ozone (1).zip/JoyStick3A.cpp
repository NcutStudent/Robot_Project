/**
  ******************************************************************************
  * @file 		JoyStick3A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "JoyStick3A.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
JoyStick3A::JoyStick3A(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void JoyStick3A::GetXY(char &X, char &Y)
{
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  	X = *((int8_t *)&__innoCommandBuff__[0]);
  	Y = *((int8_t *)&__innoCommandBuff__[1]);
  }		  	  
}
void JoyStick3A::GetZ(char &Z)
{
  __innoCommandBuff__[0] = 124;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    Z = *((int8_t *)&__innoCommandBuff__[0]);  
}
void JoyStick3A::GetXY(int8_t &X, int8_t &Y)
{
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  	X = *((int8_t *)&__innoCommandBuff__[0]);
  	Y = *((int8_t *)&__innoCommandBuff__[1]);
  }		  	  
}
void JoyStick3A::GetZ(int8_t &Z)
{
  __innoCommandBuff__[0] = 124;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    Z = *((int8_t *)&__innoCommandBuff__[0]);  
}
uint8_t JoyStick3A::Get4WayStatus(void)
{
  __innoCommandBuff__[0] = 127;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	return __innoCommandBuff__[0];
  return 0;
}
uint8_t JoyStick3A::Get8WayStatus(void)
{
  __innoCommandBuff__[0] = 128;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	return __innoCommandBuff__[0];
  return 0;
}
uint8_t JoyStick3A::GetButtonStatus(void)
{
  __innoCommandBuff__[0] = 130;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	return __innoCommandBuff__[0];
  return 0;
}
void JoyStick3A::StartCalibration(void)
{
  __innoCommandBuff__[0] = 88;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void JoyStick3A::GetPolarBinaryRadian(uint8_t &Radius , uint16_t &Angle)
{
  __innoCommandBuff__[0] = 125;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Radius = __innoCommandBuff__[0];
	  Angle = *((uint16_t *)&__innoCommandBuff__[1]);
  }	  	  
}	

void JoyStick3A::SetCalibrationX(uint16_t min, uint16_t cen, uint16_t max)
{       
  __innoCommandBuff__[0] = 89;
  *((uint16_t *)&__innoCommandBuff__[2]) = min;
  *((uint16_t *)&__innoCommandBuff__[4]) = cen;
  *((uint16_t *)&__innoCommandBuff__[6]) = max;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void JoyStick3A::GetCalibrationX(uint16_t& min, uint16_t& cen, uint16_t& max)
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 7;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  min = *((uint16_t *)&__innoCommandBuff__[0]);   
	  cen = *((uint16_t *)&__innoCommandBuff__[2]);
      max = *((uint16_t *)&__innoCommandBuff__[4]);
  }	        
}
void JoyStick3A::SetCalibrationY(uint16_t min, uint16_t cen, uint16_t max)
{       
  __innoCommandBuff__[0] = 91;
  *((uint16_t *)&__innoCommandBuff__[2]) = min;
  *((uint16_t *)&__innoCommandBuff__[4]) = cen;
  *((uint16_t *)&__innoCommandBuff__[6]) = max;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void JoyStick3A::GetCalibrationY(uint16_t& min, uint16_t& cen, uint16_t& max)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 7;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  min = *((uint16_t *)&__innoCommandBuff__[0]);   
	  cen = *((uint16_t *)&__innoCommandBuff__[2]);
      max = *((uint16_t *)&__innoCommandBuff__[4]);
  }	        
}
void JoyStick3A::SetCalibrationZ(uint16_t min, uint16_t cen, uint16_t max)
{       
  __innoCommandBuff__[0] = 93;
  *((uint16_t *)&__innoCommandBuff__[2]) = min;
  *((uint16_t *)&__innoCommandBuff__[4]) = cen;
  *((uint16_t *)&__innoCommandBuff__[6]) = max;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void JoyStick3A::GetCalibrationZ(uint16_t& min, uint16_t& cen, uint16_t& max)
{
  __innoCommandBuff__[0] = 94;
  __innoNumByteToRead__ = 7;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  min = *((uint16_t *)&__innoCommandBuff__[0]);   
	  cen = *((uint16_t *)&__innoCommandBuff__[2]);
      max = *((uint16_t *)&__innoCommandBuff__[4]);
  }	        
}
void JoyStick3A::RestoreSettings(void)
{        
  __innoCommandBuff__[0] = 95;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void JoyStick3A::SetStickDeadZone(uint8_t DZx, uint8_t DZy)
{        
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = DZx;
  __innoCommandBuff__[3] = DZy;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void JoyStick3A::GetStickDeadZone(uint8_t& DZx, uint8_t& DZy)
{
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  DZx = __innoCommandBuff__[0];   
	  DZy = __innoCommandBuff__[1];
  }	        
}
void JoyStick3A::SetRadiusDeadZone(uint8_t Dz)
{   
  __innoCommandBuff__[0] = 100;
  __innoCommandBuff__[2] = Dz;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetRadiusDeadZone(uint8_t& Dz)
{
  __innoCommandBuff__[0] = 101;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dz = __innoCommandBuff__[0];
  }	 
}
void JoyStick3A::SetXYSaturation(uint8_t Resx, uint8_t Resy)
{       
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = Resx;
  __innoCommandBuff__[3] = Resy;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void JoyStick3A::GetXYSaturation(uint8_t& Resx, uint8_t& Resy)
{
  __innoCommandBuff__[0] = 103;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Resx = __innoCommandBuff__[0];
	  Resy = __innoCommandBuff__[1];
  }	        
}
void JoyStick3A::SetRadiusSaturation(uint8_t Sat)
{     
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = Sat;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetRadiusSaturation(uint8_t& Sat)
{
  __innoCommandBuff__[0] = 107;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Sat = __innoCommandBuff__[0];
  }	    
}
void JoyStick3A::SetXYRes(uint8_t Resx, uint8_t Resy)
{        
  __innoCommandBuff__[0] = 108;
  __innoCommandBuff__[2] = Resx;
  __innoCommandBuff__[3] = Resy;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void JoyStick3A::GetXYRes(uint8_t& Resx, uint8_t& Resy)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Resx = __innoCommandBuff__[0]; 
	  Resy = __innoCommandBuff__[1];
  }	
}
void JoyStick3A::SetRadiusRes(uint8_t Res)
{     
  __innoCommandBuff__[0] = 112;
  __innoCommandBuff__[2] = Res;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetRadiusRes(uint8_t& Res)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Res = __innoCommandBuff__[0];
  }	        
}
void JoyStick3A::SetRadianRes(uint16_t Res)
{
  __innoCommandBuff__[0] = 114;
  *((uint16_t *)&__innoCommandBuff__[2]) = Res;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void JoyStick3A::GetRadianRes(uint16_t& Res)
{
  __innoCommandBuff__[0] = 115;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Res = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}
void JoyStick3A::ButtonRepeatFunc(uint8_t Func)
{   
  __innoCommandBuff__[0] = 116;
  __innoCommandBuff__[2] = Func;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::SetRepeatTime(uint8_t Time)
{
  __innoCommandBuff__[0] = 117;
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetRepeatTime(uint8_t& Time)
{
  __innoCommandBuff__[0] = 118;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Time = __innoCommandBuff__[0];
  }	        
}
void JoyStick3A::SetRepeatRate(uint8_t Rate)
{      
  __innoCommandBuff__[0] = 119;
  __innoCommandBuff__[2] = Rate;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetRepeatRate(uint8_t& Rate)
{
  __innoCommandBuff__[0] = 120;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Rate = __innoCommandBuff__[0];
  }	        
}
void JoyStick3A::SetEventRefreshRate(uint8_t Rate)
{       
  __innoCommandBuff__[0] = 121;
  __innoCommandBuff__[2] = Rate;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetEventRefreshRate(uint8_t& Rate)
{
  __innoCommandBuff__[0] = 122;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Rate = __innoCommandBuff__[0];
  }	        
}
void JoyStick3A::GetPolarRadian(float& Radius, float& Radian)
{
  __innoCommandBuff__[0] = 126;
  __innoNumByteToRead__ = 9;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Radius = *((float *)&__innoCommandBuff__);   
	  Radian = *((float *)&__innoCommandBuff__[4]);
  }	        
}

void JoyStick3A::SetKnobDeadZone(uint8_t Dz)
{       
  __innoCommandBuff__[0] = 98;
  __innoCommandBuff__[2] = Dz;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetKnobDeadZone(uint8_t& Dz)
{
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dz = __innoCommandBuff__[0];
  }	        
}
void JoyStick3A::SetKnobRes(uint8_t Res)
{       
  __innoCommandBuff__[0] = 110;
  __innoCommandBuff__[2] = Res;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void JoyStick3A::GetKnobRes(uint8_t& Res)
{
  __innoCommandBuff__[0] = 111;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Res = __innoCommandBuff__[0];
  }	        
}


