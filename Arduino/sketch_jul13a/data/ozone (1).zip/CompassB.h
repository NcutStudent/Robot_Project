/**
  ******************************************************************************
  * @file 		CompassA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *                                                                                                                                                                                                                                                                                                                                             
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_COMPASS_B
#define __INNO_COMPASS_B     
#include "innotype.h"
class CompassB
{
  private:
  uint8_t SlaveID;                                 
  public:
  CompassB(uint8_t);                                                                                                                                                                                                                                            
  void GetAngle(uint16_t&);
  void GetAngle3D(uint16_t&, uint8_t&);
  void SetTargetAngle(uint16_t);
  void SetDimension(uint8_t);                                                                                                                                                                                                                                                          
  void GetDevAngle(int16_t&);
  void SetDevAngleLimit(uint8_t);
  uint8_t GetDevAngleLimitStatus(void);
  void SetRefreshFreq(uint8_t) ;
  uint8_t GetRefreshStatus(void);
  void Calibration(uint8_t);
  
  void GetXField(int16_t&);
  void GetYField(int16_t&);
  void GetDevAngleLimit(uint8_t&);
  void GetRefreshFreq(uint8_t&);
  void RestoreDefaultCalValue(void);
  void GetZField(int16_t&);
  void GetDimension(uint8_t&);
  void SetCurrentTargetAngle(void);
  void GetTargetAngle(uint16_t&);  
  
};
#endif



