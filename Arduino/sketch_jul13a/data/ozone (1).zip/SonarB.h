/**
  ******************************************************************************
  * @file 		SonarB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	06/09/2014
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_SONAR_B
#define __INNO_SONAR_B	
#include "innotype.h" 
class SonarB
{
    private:
	uint8_t SlaveID;
	public:
	SonarB(uint8_t);
	void Ranging(void);
	void RepeatRanging(void);
	void StopRanging(void);
	uint8_t GetDistance(uint8_t, uint16_t &);
    
	void SetRangingTime(uint8_t);
	void GetRangingTime(uint8_t&);
	void SetRepeatCount(uint8_t);
	void SetRepeatTime(uint8_t);
	void GetRepeatCount(uint8_t&);
	void GetRepeatTime(uint8_t&);
  
	void GetADValue(uint8_t, uint16_t&);
	void SetMode(uint8_t);
    
};
#endif



