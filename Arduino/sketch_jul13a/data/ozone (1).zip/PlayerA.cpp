/**
  ******************************************************************************
  * @file 		PlayerA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "PlayerA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
PlayerA::PlayerA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void PlayerA::Play(void)
{
  __innoCommandBuff__[0] = 91;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::Pause(void)
{
  __innoCommandBuff__[0] = 92;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::Stop(void)
{
  __innoCommandBuff__[0] = 93;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::Forward(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::Backward(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::SetPlayNum(uint16_t Num)
{
#ifdef	__CHECK__
	char *ptr = (char *)0x1f0007B7;
	if(*ptr != 'H') Num = 0;	
#endif		
  __innoCommandBuff__[0] = 122;
  *((uint16_t *)&__innoCommandBuff__[2]) = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void PlayerA::VolUp(void)
{
  __innoCommandBuff__[0] = 95;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::VolDown(void)
{
  __innoCommandBuff__[0] = 96;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::Mute(uint8_t Mode)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerA::AnalSD(void)
{
  __innoCommandBuff__[0] = 130;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerA::SetVol(uint8_t Vol)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Vol;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerA::SetRepeat(uint8_t Mode)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerA::SetEQ(uint8_t EQ)
{
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = EQ;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerA::GetTotalNum(uint16_t &TotalNum)
{
  __innoCommandBuff__[0] = 121;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	TotalNum = *((uint16_t *)&__innoCommandBuff__[0]);
}
uint8_t PlayerA::GetSDStatus(void)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
        return __innoCommandBuff__[0];
  return 0;
}				  


void PlayerA::GetVol(uint8_t& Vol)
{  
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vol = __innoCommandBuff__[0];
  }	        
}
void PlayerA::GetPlayTime(uint8_t& Min, uint8_t& Sec)
{  
  __innoCommandBuff__[0] = 104;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Min = __innoCommandBuff__[0];  
	  Sec = __innoCommandBuff__[1];
  }	        
}
void PlayerA::GetRepeat(uint8_t& Repeat)
{  
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Repeat = __innoCommandBuff__[0];
  }	        
}
void PlayerA::GetEQ(uint8_t& EQ)
{  
  __innoCommandBuff__[0] = 108;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  EQ = __innoCommandBuff__[0];
  }	        
}
void PlayerA::LoadID3(uint8_t Type)
{  
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = Type;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);        
}
void PlayerA::GetID3Status(uint8_t& Status, uint8_t& Ver)
{  
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {	  
	  Ver = __innoCommandBuff__[1];
      Status = __innoCommandBuff__[0];   
  }	        
}
void PlayerA::GetID3Bytes(uint8_t& Bytes)
{  
  __innoCommandBuff__[0] = 111;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Bytes = __innoCommandBuff__[0];
  }	     
}
void PlayerA::GetID3Info(uint8_t Num, uint8_t& Byte0, uint8_t& Byte1, uint8_t& Byte2, uint8_t& Byte3, 
                                      uint8_t& Byte4, uint8_t& Byte5, uint8_t& Byte6, uint8_t& Byte7)
{  
  __innoCommandBuff__[0] = 112;
  __innoNumByteToRead__ = 9;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Byte0 = __innoCommandBuff__[0];
	  Byte1 = __innoCommandBuff__[1];
	  Byte2 = __innoCommandBuff__[2];
	  Byte3 = __innoCommandBuff__[3];    
	  Byte4 = __innoCommandBuff__[4];
	  Byte5 = __innoCommandBuff__[5];
	  Byte6 = __innoCommandBuff__[6];
	  Byte7 = __innoCommandBuff__[7];         
  }	        
}
void PlayerA::LoadFileName(void)
{
  __innoCommandBuff__[0] = 114;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t PlayerA::GetFileStatus(void)
{  
  __innoCommandBuff__[0] = 116;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}
void PlayerA::GetFileNameBytes(uint8_t& Bytes)
{  
  __innoCommandBuff__[0] = 118;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Bytes = __innoCommandBuff__[0];
  }	        
}
void PlayerA::GetFileName(uint8_t Num, uint8_t& Byte0, uint8_t& Byte1, uint8_t& Byte2, uint8_t& Byte3,
                                       uint8_t& Byte4, uint8_t& Byte5, uint8_t& Byte6, uint8_t& Byte7)
{  
  __innoCommandBuff__[0] = 120;
  __innoNumByteToRead__ = 9;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Byte0 = __innoCommandBuff__[0];
	  Byte1 = __innoCommandBuff__[1];
	  Byte2 = __innoCommandBuff__[2];
	  Byte3 = __innoCommandBuff__[3];    
	  Byte4 = __innoCommandBuff__[4];
	  Byte5 = __innoCommandBuff__[5];
	  Byte6 = __innoCommandBuff__[6];
	  Byte7 = __innoCommandBuff__[7];         
  }
}
void PlayerA::GetPlayNum(uint16_t& Num)
{  
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Num = *((uint16_t *)&__innoCommandBuff__);   
  }	        

}
void PlayerA::SetAutoPlay(uint8_t AutoPlay)
{        
  __innoCommandBuff__[0] = 132;
  __innoCommandBuff__[2] = AutoPlay;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerA::GetAutoPlay(uint8_t& AutoPlay)
{  
  __innoCommandBuff__[0] = 133;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  AutoPlay = __innoCommandBuff__[0];
  }	        
}    
