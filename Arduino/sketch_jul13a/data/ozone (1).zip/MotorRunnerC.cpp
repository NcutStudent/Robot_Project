/**
  ******************************************************************************
  * @file 		MotoRunnerC
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "MotorRunnerC.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
MotorRunnerC::MotorRunnerC(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void MotorRunnerC::Forward(uint8_t Speed)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B2;
	if(*ptr != 'N') __innoCommandBuff__[0] = 109;
	else 	
#endif	
  __innoCommandBuff__[0] = 108;
  __innoCommandBuff__[2] = Speed;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}     
void MotorRunnerC::Backward(uint8_t Speed)
{
  __innoCommandBuff__[0] = 109;
  __innoCommandBuff__[2] = Speed;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MotorRunnerC::SetSpdDC(uint8_t Speed)
{
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = Speed;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MotorRunnerC::SetDir(uint8_t Dir)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = Dir;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MotorRunnerC::Brake(void)
{
  __innoCommandBuff__[0] = 90;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MotorRunnerC::Stop(void)
{
  __innoCommandBuff__[0] = 91;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 

void MotorRunnerC::GetDir(uint8_t &Dir)
{
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Dir = __innoCommandBuff__[0];	  	
}
				  
void MotorRunnerC::SetTACHPeriod(uint8_t Period)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = Period;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}     
uint8_t MotorRunnerC::TACHIn(uint32_t &Speed)
{
  __innoCommandBuff__[0] = 96;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  	Speed = *((uint32_t *)&__innoCommandBuff__[1]);
    return __innoCommandBuff__[0]; 
  }
  return 0;
}
void MotorRunnerC::SetSpdCtrl(uint8_t Dir, uint32_t Speed)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Dir;
  *((uint32_t *)&__innoCommandBuff__[3]) = Speed;      
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void MotorRunnerC::SpdCtrlOn(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 
void MotorRunnerC::SpdCtrlOff(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3); 
}                            
uint8_t MotorRunnerC::GetSpdCtrlStatus(void)
{
  __innoCommandBuff__[0] = 101;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	  	
  return 0;
}  	
void MotorRunnerC::SetP(uint8_t P)
{
  __innoCommandBuff__[0] = 121;
  __innoCommandBuff__[2] = P;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void MotorRunnerC::SetI(uint8_t I)
{
  __innoCommandBuff__[0] = 123;
  __innoCommandBuff__[2] = I;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}

void MotorRunnerC::SetD(uint8_t D)
{
  __innoCommandBuff__[0] = 125;
  __innoCommandBuff__[2] = D;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);  	
}
 
void MotorRunnerC::SetScalar(uint8_t Scalar)
{
  __innoCommandBuff__[0] = 127;
  __innoCommandBuff__[2] = Scalar;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
} 

void MotorRunnerC::SetCount(uint8_t Mode, uint16_t Count)
{
  __innoCommandBuff__[0] = 102;
  __innoCommandBuff__[2] = Mode;
  *((uint16_t *)&__innoCommandBuff__[3]) = Count;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);	  	
}   	
uint8_t MotorRunnerC::GetCount(uint8_t &Mode, uint16_t &Count)
{
  __innoCommandBuff__[0] = 103;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  	Mode = __innoCommandBuff__[1];
  	Count = *((uint16_t *)&__innoCommandBuff__[2]);
    return __innoCommandBuff__[0];  
  }
  return 0;	  	   	  	
}
void MotorRunnerC::CountOn(void)
{
  __innoCommandBuff__[0] = 104;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MotorRunnerC::CountOff(void)
{
  __innoCommandBuff__[0] = 106;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t MotorRunnerC::GetCountStatus(void)
{
  __innoCommandBuff__[0] = 107;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 
  return 0;	  
} 
uint8_t MotorRunnerC::GetBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 113;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 
  return 0;	       	
}     
void MotorRunnerC::ClrBrakeButStatus(void)
{
  __innoCommandBuff__[0] = 114;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);	  	
}
uint8_t MotorRunnerC::GetFaultStatus(void)
{
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0]; 	
  return 0;
}    
void MotorRunnerC::EnFaultStop(void)
{
  __innoCommandBuff__[0] = 117;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MotorRunnerC::DisFaultStop(void)
{
  __innoCommandBuff__[0] = 118;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MotorRunnerC::ClearFault(void)
{
  __innoCommandBuff__[0] = 111;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void MotorRunnerC::RestoreStatus(void)
{
  __innoCommandBuff__[0] = 112;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
	


void MotorRunnerC::GetSpdDC(uint8_t& Spd)
{  
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Spd = __innoCommandBuff__[0];
  }	        
}
void MotorRunnerC::GetTACHPeriod(uint8_t& Period)
{        
  __innoCommandBuff__[0] = 95;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Period = __innoCommandBuff__[0];
  }	
}
uint8_t MotorRunnerC::GetSpdCtrl(uint8_t& Dir, uint32_t& Speed)
{  
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 7;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dir = __innoCommandBuff__[1];   
	  Speed = *((uint32_t *)&__innoCommandBuff__[2]);
      return __innoCommandBuff__[0];
  }	  
  return 0;  
}
void MotorRunnerC::SetVel(int16_t Vel)
{         
  __innoCommandBuff__[0] = 115;
  *((int16_t *)&__innoCommandBuff__[2]) = Vel;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void MotorRunnerC::GetVel(int16_t& Vel)
{  
  __innoCommandBuff__[0] = 116;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vel = *((int16_t *)&__innoCommandBuff__);   
  }	        
}
void MotorRunnerC::GetP(uint8_t& P)
{  
  __innoCommandBuff__[0] = 122;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  P = __innoCommandBuff__[0];
  }	        
}
void MotorRunnerC::GetI(uint8_t& I)
{  
  __innoCommandBuff__[0] = 124;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  I = __innoCommandBuff__[0];
  }	        
}
void MotorRunnerC::GetD(uint8_t& D)
{  
  __innoCommandBuff__[0] = 126;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  D = __innoCommandBuff__[0];
  }	        
}
void MotorRunnerC::GetScalar(uint8_t& Scalar)
{  
  __innoCommandBuff__[0] = 128;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Scalar = __innoCommandBuff__[0];
  }	        
}

