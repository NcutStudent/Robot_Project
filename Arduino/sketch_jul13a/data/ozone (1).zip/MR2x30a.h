/**
  ******************************************************************************
  * @file 		MR2X30A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_MR2X30A
#define __INNO_MR2X30A	  
#include "innotype.h" 
class MR2X30A
{
    private:
	uint8_t SlaveID;
	public:
	MR2X30A(uint8_t);
 	void ForwardA(uint16_t);
	void ForwardB(uint16_t);
    void ForwardAB(uint16_t, uint16_t);
	void BackwardA(uint16_t);
	void BackwardB(uint16_t);
    void BackwardAB(uint16_t, uint16_t);
	void BrakeA(void);
	void BrakeB(void);
	void BrakeDual(void);
	void StopA(void);
	void StopB(void);
	void StopDual(void);
	void SetDirAB(uint8_t, uint8_t);
	void SetVelAB(int16_t, int16_t);
    uint8_t GetBrakeButStatus(void);
	void ClrBrakeButStatus(void);
    uint8_t GetFaultStatus(void);
	void ClearFaultStatus(void);
	void EnFaultStop(void);
	void DisFaultStop(void);
    
	void ForwardDual(uint16_t);
	void BackwardDual(uint16_t);
	void SetDirA(uint8_t);
	void SetDirB(uint8_t);
	void SetDirDual(uint8_t);
	void SetDCA(uint16_t);
	void SetDCB(uint16_t);
	void SetDCAB(uint16_t, uint16_t);
	void SetDCDual(uint16_t);
	void GetDCA(uint16_t&);
	void GetDCB(uint16_t&);
	void GetDirA(uint8_t&);
	void GetDirB(uint8_t&);
	void GetDCAB(uint16_t&, uint16_t&);
	void GetDirAB(uint8_t&, uint8_t&);
	void SetVelA(int16_t);
	void SetVelB(int16_t);
	void SetVelDual(int16_t);
	void GetVelA(int16_t&);
	void GetVelB(int16_t&);
	void GetVelAB(int16_t&, int16_t&);       
};
#endif



