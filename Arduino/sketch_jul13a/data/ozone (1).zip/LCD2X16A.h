/**
  ******************************************************************************
  * @file 		LCD2X16A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_LCD2X16_A
#define __INNO_LCD2X16_A	
#include "innotype.h"
class LCD2X16A
{
    private:
	uint8_t SlaveID;
	public:
	LCD2X16A(uint8_t);
	void CursorRC(uint8_t, uint8_t);
	void BackSpace(void);
	void Clear(void);
	void ClearEOL(void);
	void ClearEOS(void);
	void BacklightOff(void);
	void BacklightOn(uint8_t);
	void CursorBlinkOff(void);
	void CursorBlinkOn(void);
	void CursorOff(void);
	void CursorOn(void);
	void DisplayOff(void);
	void DisplayOn(void);
	void RotateLeft(uint8_t, uint8_t);
	void RotateOff(void);
	void RotateRight(uint8_t, uint8_t);
	void SetBacklight(uint8_t);

	void Display(const void*, uint8_t);
	void Display(const void*);
	void DisplayChar(int8_t);

	void Display(uint8_t);
	void Display(int8_t);
	void Display(uint16_t);
	void Display(int16_t);
	void Display(uint32_t);
	void Display(int32_t);
	void Display(float, uint8_t);
	void Display(double, uint8_t);
    void Display(unsigned long long);
    void Display(long long);

	void DisplayBin(uint8_t);
	void DisplayBin(uint16_t);
	void DisplayBin(uint32_t);

	void DisplayHex(uint8_t);
	void DisplayHex(uint16_t);
	void DisplayHex(uint32_t);
    void DisplayHex(unsigned long long);
    
    
    void Home(void);
    void CursorLeft(void);
    void CursorRight(void);
    void CursorUp(void);
    void CursorDown(void);
    void SetTab(uint8_t);
    void GetTab(uint8_t&);
    void Tab(void);
    void CR(void);
    void CursorCol(uint8_t);
    void CursorRow(uint8_t);
    void CustomChar(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
    void SetBrightness(uint8_t);
};

#endif



