/**
  ******************************************************************************
  * @file 		PlayerB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	06/09/2014
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "PlayerB.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
PlayerB::PlayerB(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void PlayerB::Play(void)
{
  __innoCommandBuff__[0] = 91;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::Pause(void)
{
  __innoCommandBuff__[0] = 92;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::Stop(void)
{
  __innoCommandBuff__[0] = 93;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::Forward(void)
{
  __innoCommandBuff__[0] = 100;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::Backward(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::SetPlayNum(uint16_t Num)
{
#ifdef	__CHECK__
	char *ptr = (char *)0x1f0007B7;
	if(*ptr != 'H') Num = 0;	
#endif		
  __innoCommandBuff__[0] = 122;
  *((uint16_t *)&__innoCommandBuff__[2]) = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void PlayerB::VolUp(void)
{
  __innoCommandBuff__[0] = 95;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::VolDown(void)
{
  __innoCommandBuff__[0] = 96;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::Mute(uint8_t Mode)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerB::AnalSD(void)
{
  __innoCommandBuff__[0] = 130;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void PlayerB::SetVol(uint8_t Vol)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Vol;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerB::SetRepeat(uint8_t Mode)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerB::SetEQ(uint8_t EQ)
{
  __innoCommandBuff__[0] = 107;
  __innoCommandBuff__[2] = EQ;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerB::GetTotalNum(uint16_t &TotalNum)
{
  __innoCommandBuff__[0] = 121;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	TotalNum = *((uint16_t *)&__innoCommandBuff__[0]);
}
uint8_t PlayerB::GetSDStatus(void)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
        return __innoCommandBuff__[0];
  return 0;
}				  


void PlayerB::GetVol(uint8_t& Vol)
{  
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Vol = __innoCommandBuff__[0];
  }	        
}

void PlayerB::GetRepeat(uint8_t& Repeat)
{  
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Repeat = __innoCommandBuff__[0];
  }	        
}
void PlayerB::GetEQ(uint8_t& EQ)
{  
  __innoCommandBuff__[0] = 108;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  EQ = __innoCommandBuff__[0];
  }	        
}

void PlayerB::GetPlayNum(uint16_t& Num)
{  
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Num = *((uint16_t *)&__innoCommandBuff__);   
  }	        

}
void PlayerB::SetAutoPlay(uint8_t AutoPlay)
{        
  __innoCommandBuff__[0] = 132;
  __innoCommandBuff__[2] = AutoPlay;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void PlayerB::GetAutoPlay(uint8_t& AutoPlay)
{  
  __innoCommandBuff__[0] = 133;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  AutoPlay = __innoCommandBuff__[0];
  }	        
}    
