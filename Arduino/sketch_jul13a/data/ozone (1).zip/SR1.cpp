/**
  ******************************************************************************
  * @file 		SR1
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	06/09/2014
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "SR1.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
SR1::SR1(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
  InitArmCommander();
}
void SR1::LoadDefaultSentence(uint8_t Mode)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
uint8_t SR1::PutSentence(void* ptr)
{
  char *sptr, *ptr1;
  int8_t i;

  __innoCommandBuff__[0] = 89;
  ptr1 = sptr = (char *)ptr;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 40 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr1++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++) __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __innoNumByteToRead__ = 2;
    if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6, &__innoNumByteToRead__))
    {
      return __innoCommandBuff__[0];
    }     
  } 
  return 1; 
}
uint8_t SR1::PutWord(void* ptr)
{
  char *sptr, *ptr1;
  int8_t i;

  __innoCommandBuff__[0] = 90;
  ptr1 = sptr = (char *)ptr;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 40 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr1++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++) __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __innoNumByteToRead__ = 2;
    if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6, &__innoNumByteToRead__))
    {
      return __innoCommandBuff__[0];
    }    
  } 
  return 1;
}
void SR1::ResetSentence(void)
{
  __innoCommandBuff__[0] = 91;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t SR1::GetWord(void* array)
{
  char *ptr, *dptr;  
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 0;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    ptr = (char *)&__innoCommandBuff__[3];
    dptr = (char *)array;
    while(__innoCommandBuff__[2]--) *dptr++ = *ptr++;
  }
}
uint8_t SR1::GetSentence(void* array)
{		
  char *ptr, *dptr;  
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 0;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    ptr = (char *)&__innoCommandBuff__[3];
    dptr = (char *)array;
    while(__innoCommandBuff__[2]--) *dptr++ = *ptr++;
  }
}
uint8_t SR1::SaveSentence(uint8_t ID)
{
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = ID;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
    return __innoCommandBuff__[0];
  }
  return 1;
}
uint8_t SR1::LoadSentence(uint8_t ID)
{
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = ID;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
    return __innoCommandBuff__[0];
  } 
  return 1;
}
uint8_t SR1::DeleteSentence(uint8_t ID)
{
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = ID;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
    return __innoCommandBuff__[0];
  }
  return 1;
}
void SR1::DeleteAllSentence(void)
{
  __innoCommandBuff__[0] = 99;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t SR1::GoRecognition(void)
{
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    return __innoCommandBuff__[0];
  }
  return 1;
}
uint8_t SR1::GetRecognition(uint8_t &ID)
{
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    ID = __innoCommandBuff__[1];
    return __innoCommandBuff__[0];
  }
  return 1;
}



