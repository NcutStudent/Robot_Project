/**
  ******************************************************************************
  * @file 		RF24G
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "RF24G.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
RF24G::RF24G(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}

void RF24G::SendVar(char var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 1;
  *((int8_t *)&__innoCommandBuff__[3]) = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendVar(int8_t var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 1;
  *((int8_t *)&__innoCommandBuff__[3]) = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendVar(uint8_t var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 1;
  __innoCommandBuff__[3] = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendVar(int16_t var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 2;
  *((int16_t *)&__innoCommandBuff__[3]) = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendVar(uint16_t var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 2;
  *((uint16_t *)&__innoCommandBuff__[3]) = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendVar(int32_t var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 4;
  *((int32_t *)&__innoCommandBuff__[3]) = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendVar(uint32_t var)
{
  __innoCommandBuff__[0] = 103;
  __innoCommandBuff__[2] = 4;
  *((uint32_t *)&__innoCommandBuff__[3]) = var;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::SendArray(const void* str)
{
  char *ptr, *sptr;
  int8_t i;
  __innoCommandBuff__[0] = 104;
  sptr = ptr = (char *)str;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 20 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++) __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __i2cWriteBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6);
  }
}
void RF24G::SendString(const void* str)
{
  char *ptr, *sptr;
  int8_t i;
  __innoCommandBuff__[0] = 104;
  sptr = ptr = (char *)str;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 20 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++) __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __i2cWriteBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6);
  }
}
void RF24G::GetVar(uint8_t &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((uint8_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetVar(char &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((int8_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetVar(int8_t &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((int8_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetVar(uint16_t &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((uint16_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetVar(int16_t &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((int16_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetVar(uint32_t &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((uint32_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetVar(int32_t &var)
{
  __innoCommandBuff__[0] = 109;
  __innoNumByteToRead__ = 6;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    var = *((int32_t *)&__innoCommandBuff__[1]);
  }
}
void RF24G::GetArray(void* array)
{
  char *ptr, *dptr;  
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 0;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    ptr = (char *)&__innoCommandBuff__[3];
    dptr = (char *)array;
    while(__innoCommandBuff__[2]--) *dptr++ = *ptr++;
  }
}
void RF24G::GetString(void* str)
{
  char *ptr, *dptr;  
  __innoCommandBuff__[0] = 110;
  __innoNumByteToRead__ = 0;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    ptr = (char *)&__innoCommandBuff__[3];
    dptr = (char *)str;
    while(__innoCommandBuff__[2]--) *dptr++ = *ptr++;
    *ptr = 0;
  }
}
void RF24G::ClrBuffer(void)
{
  __innoCommandBuff__[0] = 111;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void RF24G::SetMode(uint8_t Mode)
{
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void RF24G::SetCh(uint8_t Ch)
{
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = Ch;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void RF24G::SetRFID(uint8_t RFID)
{
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = RFID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void RF24G::SetRegCode(uint8_t Reg)
{
  __innoCommandBuff__[0] = 98;
  __innoCommandBuff__[2] = Reg;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void RF24G::Config(void)
{
  __innoCommandBuff__[0] = 102;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void RF24G::BufferVar(uint8_t len, uint32_t Data)
{
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = len;
  *((uint32_t *)&__innoCommandBuff__[3]) = Data;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}
void RF24G::BufferArray(void* str)
{
  char *ptr, *sptr;
  int8_t i;
  __innoCommandBuff__[0] = 106;
  sptr = ptr = (char *)str;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 20 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++) __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __i2cWriteBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6);
  }

}
void RF24G::BufferString(void* str)
{
  char *ptr, *sptr;
  int8_t i;
  __innoCommandBuff__[0] = 106;
  sptr = ptr = (char *)str;
  for(__innoCommandBuff__[3] = 0 ; __innoCommandBuff__[3] < 20 ; __innoCommandBuff__[3]++)
  {
    if(!(*ptr++)) break;
  }
  if(__innoCommandBuff__[3])
  {
    for(i = 0 ; i < __innoCommandBuff__[3] ; i++) __innoCommandBuff__[i+4] = *sptr++;
    __innoCommandBuff__[2] = __innoCommandBuff__[3] + 3;
    __i2cWriteBuffer(__innoCommandBuff__, SlaveID, __innoCommandBuff__[3]+6);
  }
}
void RF24G::SendBuffer(void)
{
  __innoCommandBuff__[0] = 107;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
uint8_t RF24G::GetStatus(void)
{
  __innoCommandBuff__[0] = 108;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0];
  return 0;
}




