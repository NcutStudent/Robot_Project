/**
  ******************************************************************************
  * @file 		IOExtenderA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "IRController.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
IRController::IRController(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void IRController::GetMaxID(uint8_t &ID)
{
  __innoCommandBuff__[0] = 88;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  ID = __innoCommandBuff__[0];
  }	  
}
void IRController::GetMaxVal(uint16_t &Value)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Value = *((uint16_t *)&__innoCommandBuff__[0]);
  }
}
void IRController::GetVal(uint8_t ID, uint16_t& Value)
{
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = ID;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Value = *((uint16_t *)&__innoCommandBuff__[0]);
  }
}
void IRController::GetMinID(uint8_t& ID)
{
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  ID = __innoCommandBuff__[0];
  }
}
void IRController::GetMinVal(uint16_t& Value)
{
  __innoCommandBuff__[0] = 92;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Value = *((uint16_t *)&__innoCommandBuff__[0]);
  }
}
void IRController::GetAvgVal(uint16_t& Value)
{
  __innoCommandBuff__[0] = 93;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Value = *((uint16_t *)&__innoCommandBuff__[0]);
  }
}
void IRController::GetMax(uint8_t& ID, uint16_t& Value)
{
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  ID = __innoCommandBuff__[0];
      Value = *((uint16_t *)&__innoCommandBuff__[1]);
  }
}
void IRController::GetMin(uint8_t& ID, uint16_t& Value)
{
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  ID = __innoCommandBuff__[0];
      Value = *((uint16_t *)&__innoCommandBuff__[1]);
  }
}
void IRController::SetThreshold(int16_t Threshold)
{
  __innoCommandBuff__[0] = 101;
  *((int16_t *)&__innoCommandBuff__[2]) = Threshold;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void IRController::GetThreshold(int16_t &Threshold)
{
  __innoCommandBuff__[0] = 102;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Threshold = *((int16_t *)&__innoCommandBuff__[0]);
  }
}
uint8_t IRController::GetIRStatus(void)
{
  __innoCommandBuff__[0] = 103;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }
  return 0;
}