/**
  ******************************************************************************
  * @file 		Accelerometer3A
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_ACCELEROMETER3A
#define __INNO_ACCELEROMETER3A	 
#include "innotype.h"
class Accelerometer3A
{
private:
	uint8_t SlaveID;
public:
	Accelerometer3A(uint8_t);
	void GetXYZForce(int16_t&, int16_t&, int16_t&);
	void GetAngle2D(uint16_t&);
	void SaveAngle2D(uint8_t, uint16_t);
	void GetDevAngle2D(uint8_t, int16_t&);
	void SetMode(uint8_t);
	void SetAxis2D(uint8_t);
	void GetXADVal(uint16_t&);
	void GetYADVal(uint16_t&);
	void GetZADVal(uint16_t&);
	void GetAngle3D (uint16_t&, uint8_t&);
	void SetRefreshFreq(uint8_t);
	uint8_t GetRefreshStatus(void);

    void GetMode(uint8_t&);    
    void GetXForce(int16_t&);
    void GetYForce(int16_t&);
    void GetZForce(int16_t&);
    void GetForce2D(uint16_t&, uint16_t&);
    void GetForce3D(uint16_t&, uint16_t&, uint8_t&);
    void GetRefreshFreq(uint8_t&);
    void SaveCurrAngle2D(uint8_t);
    void LoadAngle2D(uint8_t, uint16_t&);
    void SetDevAngleLimit2D(uint8_t);
    void GetDevAngleLimit2D(uint8_t&);
    void SetDevAngleNum2D(uint8_t);
    void GetDevAngleNum2D(uint8_t&);
    uint8_t GetDevAngleLimitStatus2D(void);
    void SaveCurrAngle3D(uint8_t);
    void SaveAngle3D(uint8_t, uint16_t, uint8_t);
    void LoadAngle3D(uint8_t, uint16_t&, uint8_t&);
    void GetDevAngle3D(uint8_t, int16_t&, int16_t&);
    void SetXForceLimit(uint8_t, uint16_t);
    void GetXForceLimit(uint8_t, uint16_t&);
    uint8_t GetXForceLimitStatus(void);
    void SetYForceLimit(uint8_t, uint16_t);
    void GetYForceLimit(uint8_t, uint16_t&);
    uint8_t GetYForceLimitStatus(void);
    void SetZForceLimit(uint8_t, uint16_t); 
    void GetZForceLimit(uint8_t, uint16_t&);
    uint8_t GetZForceLimitStatus(void);
    void SetForceLimit2D(uint8_t, uint16_t); 
    void GetForceLimit2D(uint8_t, uint16_t&);
    uint8_t GetForceLimit2DStatus(void);
    void SetForceLimit3D(uint8_t, uint16_t); 
    void GetForceLimit3D(uint8_t, uint16_t&);
    uint8_t GetForceLimit3DStatus(void);
    void GetMaxXForce(int16_t&); 
    void GetMaxYForce(int16_t&);    
    void GetMaxZForce(int16_t&);    
    void GetMaxForce2D(int16_t&, uint16_t&);   
    void GetMaxForce3D(int16_t&, uint16_t&, uint8_t&); 
    void ClrMaxXForce(void); 
    void ClrMaxYForce(void); 
    void ClrMaxZForce(void); 
    void ClrMaxForce2D(void); 
    void ClrMaxForce3D(void); 
    void SaveCalVal(uint8_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t);
    void LoadCalVal(uint8_t, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&);
    void RestoreCalVal(void); 
    void GetAxis2D(uint8_t&);   
           
};
#endif



