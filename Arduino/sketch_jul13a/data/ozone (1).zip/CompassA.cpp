/**
  ******************************************************************************
  * @file 		CompassA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "CompassA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/

CompassA::CompassA(uint8_t mySlaveID)   
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void CompassA::GetXYField(int16_t &XField, int16_t &YField)    
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  XField = *((int16_t *)&__innoCommandBuff__[0]);	 
	  YField = *((int16_t *)&__innoCommandBuff__[2]);
  }	  
#ifdef __CHECK__
	char *ptr = (char *)0x1f000700;
	if(*(ptr+0xB3) != 'O') XField = YField;
#endif	
}	
void CompassA::GetAngle(uint16_t &Angle)
{
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    Angle = *((uint16_t *)&__innoCommandBuff__[0]);
}
void CompassA::SaveAngle(uint8_t no, uint16_t Angle)
{
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = no;
  *((uint16_t *)&__innoCommandBuff__[3]) = Angle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void CompassA::GetDevAngle(uint8_t no, int16_t &Angle)
{
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = no;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  	Angle = *((int16_t *)&__innoCommandBuff__[0]);
}
void CompassA::GetHxHyHz(int16_t &Hx, int16_t &Hy, int16_t &Hz)
{
  __innoCommandBuff__[0] = 120;
  __innoNumByteToRead__ = 7;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Hx = *((int16_t *)&__innoCommandBuff__[0]);
	  Hy = *((int16_t *)&__innoCommandBuff__[2]);
	  Hz = *((int16_t *)&__innoCommandBuff__[4]);
  }	        	  
}
void CompassA::SetRefreshFreq(uint8_t RefreshFreq)
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = RefreshFreq;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
uint8_t CompassA::GetRefreshStatus(void)
{
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0];
  return 0;  
}
void CompassA::Calibration(uint8_t Time)
{
  __innoCommandBuff__[0] = 89;  
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}						  

void CompassA::GetXField(int16_t& Field)
{
  __innoCommandBuff__[0] = 88;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Field = *((int16_t *)&__innoCommandBuff__); 
  }	  
}

void CompassA::GetYField(int16_t& Field)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Field = *((int16_t *)&__innoCommandBuff__);
  }	        
}

void CompassA::GetField(uint16_t& XField, uint16_t& YField)
{
  __innoCommandBuff__[0] = 90;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  XField = *((uint16_t *)&__innoCommandBuff__);   
	  YField = *((uint16_t *)&__innoCommandBuff__[2]);  
  }	        
}

void CompassA::SaveCurrAngle(uint8_t Number)
{
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = Number;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

void CompassA::LoadAngle(uint8_t Number, uint16_t& Angle)
{
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Number;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Angle = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}

void CompassA::SetDevAngleLimit(uint8_t Angle)
{     
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Angle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

void CompassA::GetDevAngleLimit(uint8_t& Angle)
{
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Angle = __innoCommandBuff__[0];
  }	        
}

void CompassA::SetDevAngleNum(uint8_t Num)
{
  __innoCommandBuff__[0] = 99;
  __innoCommandBuff__[2] = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

void CompassA::GetDevAngleNum(uint8_t& Num)
{
  __innoCommandBuff__[0] = 100;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Num = __innoCommandBuff__[0];
  }	        
}

uint8_t CompassA::GetDevAngleLimitStatus(void)
{
  __innoCommandBuff__[0] = 103;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;
}

void CompassA::GetRefreshFreq(uint8_t& Freq)
{
  __innoCommandBuff__[0] = 105;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Freq = __innoCommandBuff__[0]; 
  }	     
}

void CompassA::SaveDefaultCalValue(void)
{     
  __innoCommandBuff__[0] = 122;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}

void CompassA::GetCalValue(int16_t& X, int16_t& Y)
{
  __innoCommandBuff__[0] = 123;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  X = *((int16_t *)&__innoCommandBuff__);   
	  Y = *((int16_t *)&__innoCommandBuff__[2]);   
  }	 
}

void CompassA::LoadDefaultCalValue(void)
{        
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}

