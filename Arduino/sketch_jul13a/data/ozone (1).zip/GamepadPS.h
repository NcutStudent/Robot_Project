/**
  ******************************************************************************
  * @file 		GamepadPS
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_GAMEPAD_PS
#define __INNO_GAMEPAD_PS   
#include "innotype.h" 	   
class GamepadPS
{
    private:
	uint8_t SlaveID;
	public:
	GamepadPS(uint8_t);
	void GetLXYPos(char&, char&);
	void GetRXYPos(char&, char&);
	void GetLXYPos(int8_t&, int8_t&);
	void GetRXYPos(int8_t&, int8_t&); 
    void GetLXYPos(int16_t&, int16_t&);
	void GetRXYPos(int16_t&, int16_t&);   
	void GetL4WayValue(uint8_t&);
	void GetR4WayValue(uint8_t&);
	void GetL8WayValue(uint8_t&);
	void GetR8WayValue(uint8_t&);
	uint16_t GetKeyStatus(void);
	void GetDir4Way(uint8_t&);
    void GetDir4Way(int16_t &);
	void GetDir8Way(uint8_t&);
	void StartVib(uint8_t, uint8_t);
	void StopVib(void);
	void StickCalibration(void);
    
	void SetCalibrationLX(uint8_t, uint8_t, uint8_t);
	void GetCalibrationLX(uint8_t&, uint8_t&, uint8_t&);
	void SetCalibrationLY(uint8_t, uint8_t, uint8_t);
	void GetCalibrationLY(uint8_t&, uint8_t&, uint8_t&);
	void SetCalibrationRX(uint8_t, uint8_t, uint8_t);
	void GetCalibrationRX(uint8_t&, uint8_t&, uint8_t&);
	void SetCalibrationRY(uint8_t, uint8_t, uint8_t);
	void GetCalibrationRY(uint8_t&, uint8_t&, uint8_t&);
	void RestoreSettings(void);
	void SetLStickDeadZone(uint8_t, uint8_t);
	void GetLStickDeadZone(uint8_t&, uint8_t&);
	void SetRStickDeadZone(uint8_t, uint8_t);
	void GetRStickDeadZone(uint8_t&, uint8_t&);
	void SetLStickSaturation(uint8_t, uint8_t);
	void GetLStickSaturation(uint8_t&, uint8_t&);
	void SetRStickSaturation(uint8_t, uint8_t);
	void GetRStickSaturation(uint8_t&, uint8_t&);
	void SetLStickRes(uint8_t, uint8_t);
	void GetLStickRes(uint8_t&, uint8_t&);
	void SetRStickRes(uint8_t, uint8_t);
	void GetRStickRes(uint8_t&, uint8_t&);
	void SetStickRefreshRate(uint8_t);
	void GetStickRefreshRate(uint8_t&);
	void SetKeyRepeatFunc(uint16_t);
	void SetRepeatTime(uint8_t);
	void GetRepeatTime(uint8_t&);
	void SetRepeatRate(uint8_t);
	void GetRepeatRate(uint8_t&);
	void GetKeyRepeatFunc(uint16_t&);
	void GetAnalog(uint8_t&);
	void GetConnect(uint8_t&);
	void GetVibStatus(uint8_t&, uint8_t&, uint8_t&);
	void SetAnalog(uint8_t); 
    
};
#endif



