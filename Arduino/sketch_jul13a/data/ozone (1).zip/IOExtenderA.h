/**
  ******************************************************************************
  * @file 		IOExtenderA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_IOEXTENDER_A
#define __INNO_IOEXTENDER_A	 
#include "innotype.h"
class IOExtenderA
{
    private:
	uint8_t SlaveID;
	public:
	IOExtenderA(uint8_t);
	void High(uint8_t);
	void Low(uint8_t);
	void In(uint8_t, uint8_t&);
	void PulseOut(uint8_t, uint8_t, uint16_t);
	void ReadPort(uint8_t, uint8_t&);
	void WritePort(uint8_t, uint8_t);
	void GetADC(uint8_t, uint16_t&);
	void SetADC(uint8_t);
	void GetTimer(uint16_t&);
	void SetTimer(uint8_t, uint16_t);
	void TimerOff(void);
	void TimerOn(void);
    void SetDirPort(uint8_t, uint8_t);
    
    uint8_t GetPort0LowEventStatus(void);
    uint8_t GetPort1LowEventStatus(void);
    uint8_t GetPort2LowEventStatus(void);
    uint8_t GetPort0HighEventStatus(void);
    uint8_t GetPort1HighEventStatus(void);
    uint8_t GetPort2HighEventStatus(void);
    uint8_t GetPort0ChangeEventStatus(void);
    uint8_t GetPort1ChangeEventStatus(void);
    uint8_t GetPort2ChangeEventStatus(void);
    //void GetPulseWidth=_LOAD_0M_T(%MID%,103,&%ARG1%,sizeof %ARG1%);
    //void PulseInOff(void);
    //void GetCounter=_LOAD_0M_T(%MID%,106,&%ARG1%,sizeof %ARG1%);
    void CounterOff(void);
    //void CounterOn=_LOAD_4B_0(%MID%,108,%ARG1%,(char)(%ARG2%),(char)(%ARG2%>>8),%ARG3%);
    //void PulseOut=_LOAD_WW_0(%MID%,113,(int)(%ARG1%)|((int)(%ARG2%)<<8),%ARG3%);
    void PFDOff(void);
    void PFDOn(void);
    void SetPFD(uint16_t);
    void Toggle(uint8_t);
    void TogglePort2(void);
    void TogglePort1(void);
    void TogglePort0(void);
    void ReadPort2(uint8_t&);	
    void ReadPort1(uint8_t&);	
    void ReadPort0(uint8_t&);	
    void WritePort2(uint8_t);
    void WritePort1(uint8_t);
    void WritePort0(uint8_t);
    void SetDirPort0(uint8_t);
    void SetDirPort1(uint8_t);
    void SetDirPort2(uint8_t);
    void GetDirPort(uint8_t&, uint8_t&, uint8_t&); 
    void GetDirPort0(uint8_t&);			
    void GetDirPort1(uint8_t&);				
    void GetDirPort2(uint8_t&);		   
    
};
#endif



