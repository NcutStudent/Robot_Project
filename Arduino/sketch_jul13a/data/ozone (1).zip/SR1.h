/**
  ******************************************************************************
  * @file 		PlayerB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	06/09/2014
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_SR1
#define __INNO_SR1	 
#include "innotype.h" 
class SR1
{
private:
	uint8_t SlaveID;
public:
	SR1(uint8_t);
  void LoadDefaultSentence(uint8_t);
  uint8_t PutSentence(void*);
  uint8_t PutWord(void*);
  void ResetSentence(void);
  uint8_t GetWord(void*);
  uint8_t GetSentence(void*);
  uint8_t SaveSentence(uint8_t);
  uint8_t LoadSentence(uint8_t);
  uint8_t DeleteSentence(uint8_t);
  void DeleteAllSentence(void);
  uint8_t GoRecognition(void);
  uint8_t GetRecognition(uint8_t &);
};
#endif



