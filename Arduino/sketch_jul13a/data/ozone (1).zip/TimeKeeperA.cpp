/**
  ******************************************************************************
  * @file 		TimeKeeperA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "TimeKeeperA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
TimeKeeperA::TimeKeeperA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void TimeKeeperA::SetTimeAndDate(uint8_t Year, uint8_t Month, uint8_t Day, uint8_t Hour, uint8_t Minute, uint8_t Second)
{
  __innoCommandBuff__[0] = 88;
  __innoCommandBuff__[2] = Year;
  __innoCommandBuff__[3] = Month;
  __innoCommandBuff__[4] = Day;
  __innoCommandBuff__[5] = Hour;
  __innoCommandBuff__[6] = Minute;
  __innoCommandBuff__[7] = Second;                        	  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 10);
}
void TimeKeeperA::GetTimeAndDate(uint8_t &Year, uint8_t &Month, uint8_t &Day, uint8_t &WeekDay, uint8_t &Hour, uint8_t &Minute, uint8_t &Second)
{
  __innoCommandBuff__[0] = 96;
  __innoNumByteToRead__ = 8;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Year = __innoCommandBuff__[0];
	  Month = __innoCommandBuff__[1];
	  Day = __innoCommandBuff__[2];
      WeekDay = __innoCommandBuff__[3];
	  Hour = __innoCommandBuff__[4];
	  Minute = __innoCommandBuff__[5];
	  Second = __innoCommandBuff__[6];
  }	    	  
}
void TimeKeeperA::CountDownTimerOn(uint8_t TimerID)
{
  __innoCommandBuff__[0] = 133;
  __innoCommandBuff__[2] = TimerID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::CountDownTimerOff(uint8_t TimerID)
{
  __innoCommandBuff__[0] = 134;
  __innoCommandBuff__[2] = TimerID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::GetCountDownTimer(uint8_t TimerID, uint8_t &Day, uint8_t &Hour, uint8_t &Minute, uint8_t &Second)
{
  __innoCommandBuff__[0] = 132;
  __innoCommandBuff__[2] = TimerID;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Day = __innoCommandBuff__[0];
	  Hour = __innoCommandBuff__[1];
	  Minute = __innoCommandBuff__[2];
	  Second = __innoCommandBuff__[3];
  }	    	  
}
void TimeKeeperA::SetCountDownTimer(uint8_t TimerID, uint8_t Day, uint8_t Hour, uint8_t Minute, uint8_t Second)
{
  __innoCommandBuff__[0] = 131;
  __innoCommandBuff__[2] = TimerID;
  __innoCommandBuff__[3] = Day;
  __innoCommandBuff__[4] = Hour;
  __innoCommandBuff__[5] = Minute;
  __innoCommandBuff__[6] = Second;  
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 9);
}				  



void TimeKeeperA::SetYear(uint8_t Year)
{         
  __innoCommandBuff__[0] = 89;
  __innoCommandBuff__[2] = Year;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::SetMonth(uint8_t Month)
{         
  __innoCommandBuff__[0] = 90;
  __innoCommandBuff__[2] = Month;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::SetDay(uint8_t Day)
{         
  __innoCommandBuff__[0] = 91;
  __innoCommandBuff__[2] = Day;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}

void TimeKeeperA::SetHour(uint8_t Hour)
{         
  __innoCommandBuff__[0] = 92;
  __innoCommandBuff__[2] = Hour;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::Set12Hour(uint8_t Hour, uint8_t AMPM)
{         
  __innoCommandBuff__[0] = 93;
  __innoCommandBuff__[2] = Hour;
  __innoCommandBuff__[3] = AMPM;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void TimeKeeperA::SetMinute(uint8_t Minute)
{         
  __innoCommandBuff__[0] = 94;
  __innoCommandBuff__[2] = Minute;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::SetSecond(uint8_t Second)
{         
  __innoCommandBuff__[0] = 95;
  __innoCommandBuff__[2] = Second;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::GetYear(uint8_t& Year)
{  
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Year = __innoCommandBuff__[0];
  }	        
}
void TimeKeeperA::GetMonth(uint8_t& Month)
{  
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Month = __innoCommandBuff__[0];
  }	        
}
void TimeKeeperA::GetDay(uint8_t& Day)
{  
  __innoCommandBuff__[0] = 99;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Day = __innoCommandBuff__[0];
  }	        
}

void TimeKeeperA::GetWeekDay(uint8_t& WeekDay)
{  
  __innoCommandBuff__[0] = 100;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  WeekDay = __innoCommandBuff__[0];
  }	        
}
void TimeKeeperA::GetHour(uint8_t& Hour)
{  
  __innoCommandBuff__[0] = 101;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Hour = __innoCommandBuff__[0];
  }	        
}
void TimeKeeperA::Get12Hour(uint8_t& Hour, uint8_t& AMPM)
{  
  __innoCommandBuff__[0] = 102;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Hour = __innoCommandBuff__[0];
      AMPM = __innoCommandBuff__[1];
  }	        
}
void TimeKeeperA::GetMinute(uint8_t& Minute)
{  
  __innoCommandBuff__[0] = 103;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Minute = __innoCommandBuff__[0];
  }	        
}
void TimeKeeperA::GetSecond(uint8_t& Second)
{  
  __innoCommandBuff__[0] = 104;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {  
	  Second = __innoCommandBuff__[0];
  }	        
}
void TimeKeeperA::SetSubTime(uint8_t SubID, uint8_t Hour, uint8_t Minute, uint8_t Second)
{         
  __innoCommandBuff__[0] = 105;
  __innoCommandBuff__[2] = SubID;
  __innoCommandBuff__[3] = Hour;
  __innoCommandBuff__[4] = Minute;
  __innoCommandBuff__[5] = Second;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void TimeKeeperA::GetSubTime(uint8_t SubID, uint8_t& Hour, uint8_t& Minute, uint8_t& Second)
{  
  __innoCommandBuff__[0] = 106;
  __innoCommandBuff__[2] = SubID;  
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Hour = __innoCommandBuff__[0];   
	  Minute = __innoCommandBuff__[1];
      Second = __innoCommandBuff__[2];
  }	        
}
void TimeKeeperA::SetMonthlyAlarm(uint8_t AlarmID, uint8_t Day, uint8_t Hour, uint8_t Minute)
{         
  __innoCommandBuff__[0] = 115;
  __innoCommandBuff__[2] = AlarmID;
  __innoCommandBuff__[3] = Day;
  __innoCommandBuff__[4] = Hour;    
  __innoCommandBuff__[5] = Minute;    
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void TimeKeeperA::SetWeeklyAlarm(uint8_t AlarmID, uint8_t WeekDay, uint8_t Hour, uint8_t Minute)
{         
  __innoCommandBuff__[0] = 116;
  __innoCommandBuff__[2] = AlarmID;
  __innoCommandBuff__[3] = WeekDay;
  __innoCommandBuff__[4] = Hour;    
  __innoCommandBuff__[5] = Minute;        
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 8);
}
void TimeKeeperA::SetDailyAlarm(uint8_t AlarmID, uint8_t Hour, uint8_t Minute)
{         
  __innoCommandBuff__[0] = 117;
  __innoCommandBuff__[2] = AlarmID;
  __innoCommandBuff__[3] = Hour;    
  __innoCommandBuff__[4] = Minute;         
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 7);
}
void TimeKeeperA::SetHourlyAlarm(uint8_t AlarmID, uint8_t Minute)
{         
  __innoCommandBuff__[0] = 118;
  __innoCommandBuff__[2] = AlarmID;
  __innoCommandBuff__[3] = Minute;        
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void TimeKeeperA::GetMonthlyAlarm(uint8_t AlarmID, uint8_t& Day, uint8_t& Hour, uint8_t& Minute)
{  
  __innoCommandBuff__[0] = 119;
  __innoCommandBuff__[2] = AlarmID;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Day = __innoCommandBuff__[0];   
	  Hour = __innoCommandBuff__[1];
      Minute = __innoCommandBuff__[2];
  }	        

}

void TimeKeeperA::GetWeeklyAlarm(uint8_t AlarmID, uint8_t& WeekDay, uint8_t& Hour, uint8_t& Minute)
{  
  __innoCommandBuff__[0] = 120;
  __innoCommandBuff__[2] = AlarmID;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  WeekDay = __innoCommandBuff__[0];   
	  Hour = __innoCommandBuff__[1];
      Minute = __innoCommandBuff__[2];
  }	        

}

void TimeKeeperA::GetDailyAlarm(uint8_t AlarmID, uint8_t& Hour, uint8_t& Minute)
{  
  __innoCommandBuff__[0] = 121;
  __innoCommandBuff__[2] = AlarmID;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Hour = __innoCommandBuff__[0];
      Minute = __innoCommandBuff__[1];
  }	        

}

void TimeKeeperA::GetHourlyAlarm(uint8_t AlarmID, uint8_t& Minute)
{  

  __innoCommandBuff__[0] = 122;
  __innoCommandBuff__[2] = AlarmID;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  { 
	  Minute = __innoCommandBuff__[0];
  }	        

}

void TimeKeeperA::MonthlyAlarmOn(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 123;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::WeeklyAlarmOn(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 124;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::DailyAlarmOn(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 125;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::HourlyAlarmOn(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 126;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::MonthlyAlarmOff(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 127;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::WeeklyAlarmOff(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 128;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::DailyAlarmOff(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 129;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::HourlyAlarmOff(uint8_t AlarmID)
{         
  __innoCommandBuff__[0] = 130;
  __innoCommandBuff__[2] = AlarmID;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::ResetTimeAndDate(void)
{         
  __innoCommandBuff__[0] = 135;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void TimeKeeperA::SetAdjustment(uint8_t Adj)
{         
  __innoCommandBuff__[0] = 136;
  __innoCommandBuff__[2] = Adj;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void TimeKeeperA::GetAdjustment(uint8_t& Adj)
{  
  __innoCommandBuff__[0] = 137;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Adj = __innoCommandBuff__[0];
  }	        

}

 
