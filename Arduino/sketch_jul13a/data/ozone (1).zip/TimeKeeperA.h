/**
  ******************************************************************************
  * @file 		TimeKeeperA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_TIMEKEEPER_A
#define __INNO_TIMEKEEPER_A	
#include "innotype.h"
class TimeKeeperA
{
    private:
	uint8_t SlaveID;
	public:
	TimeKeeperA(uint8_t);
	void SetTimeAndDate(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
	void GetTimeAndDate(uint8_t&, uint8_t&, uint8_t&, uint8_t&, uint8_t&, uint8_t&, uint8_t&);
	void CountDownTimerOn(uint8_t);
	void CountDownTimerOff(uint8_t);
	void GetCountDownTimer(uint8_t, uint8_t&, uint8_t&, uint8_t&, uint8_t&);
	void SetCountDownTimer(uint8_t, uint8_t, uint8_t, uint8_t, uint8_t);
     
	void SetYear(uint8_t);
	void SetMonth(uint8_t);
	void SetDay(uint8_t);
	void SetHour(uint8_t);
	void Set12Hour(uint8_t, uint8_t);
	void SetMinute(uint8_t);
	void SetSecond(uint8_t);
	void GetYear(uint8_t&);
	void GetMonth(uint8_t&);
	void GetDay(uint8_t&);
	void GetWeekDay(uint8_t&);
	void GetHour(uint8_t&);
	void Get12Hour(uint8_t&, uint8_t&);
	void GetMinute(uint8_t&);
	void GetSecond(uint8_t&);
	void SetSubTime(uint8_t, uint8_t, uint8_t, uint8_t);
    void GetSubTime(uint8_t, uint8_t&, uint8_t&, uint8_t&);
    void SetMonthlyAlarm(uint8_t, uint8_t, uint8_t, uint8_t);
    void SetWeeklyAlarm(uint8_t, uint8_t, uint8_t, uint8_t);
    void SetDailyAlarm(uint8_t, uint8_t, uint8_t);
    void SetHourlyAlarm(uint8_t, uint8_t);
    void GetMonthlyAlarm(uint8_t, uint8_t&, uint8_t&, uint8_t&);
    void GetWeeklyAlarm(uint8_t, uint8_t&, uint8_t&, uint8_t&);
    void GetDailyAlarm(uint8_t, uint8_t&, uint8_t&);
    void GetHourlyAlarm(uint8_t, uint8_t&);
    void MonthlyAlarmOn(uint8_t);
    void WeeklyAlarmOn(uint8_t);
    void DailyAlarmOn(uint8_t);
    void HourlyAlarmOn(uint8_t);
    void MonthlyAlarmOff(uint8_t);
    void WeeklyAlarmOff(uint8_t);
    void DailyAlarmOff(uint8_t);
    void HourlyAlarmOff(uint8_t);
    void ResetTimeAndDate(void);
    void SetAdjustment(uint8_t);
    void GetAdjustment(uint8_t&);  
};
#endif



