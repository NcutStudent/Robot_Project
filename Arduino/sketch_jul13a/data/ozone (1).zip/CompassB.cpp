/**
  ******************************************************************************
  * @file 		CompassA
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "CompassB.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
CompassB::CompassB(uint8_t mySlaveID)   
{
	SlaveID = mySlaveID;
    InitArmCommander();
}

void CompassB::GetAngle(uint16_t &Angle)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B3;
	if(*ptr != 'O') return;
#endif	
  __innoCommandBuff__[0] = 91;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    Angle = *((uint16_t *)&__innoCommandBuff__[0]);
}
void CompassB::GetAngle3D(uint16_t &Angle1, uint8_t &Angle2)
{
#ifdef __CHECK__
	char *ptr = (char *)0x1f0007B3;
	if(*ptr != 'O') return;
#endif	  
  __innoCommandBuff__[0] = 136;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__)) {
    Angle1 = *((uint16_t *)&__innoCommandBuff__[0]);
    Angle2 = __innoCommandBuff__[2];
  }
}
void CompassB::SetTargetAngle(uint16_t Angle)
{
  __innoCommandBuff__[0] = 134;
  *((uint16_t *)&__innoCommandBuff__[2]) = Angle;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}
void CompassB::SetDimension(uint8_t Dimension)
{
  __innoCommandBuff__[0] = 131;
  __innoCommandBuff__[2] = Dimension;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void CompassB::SetDevAngleLimit(uint8_t Limit)
{
  __innoCommandBuff__[0] = 97;
  __innoCommandBuff__[2] = Limit;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void CompassB::GetDevAngle(int16_t &Angle)
{
  __innoCommandBuff__[0] = 96;
  __innoCommandBuff__[2] = 0;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  	Angle = *((int16_t *)&__innoCommandBuff__[0]);
}

void CompassB::SetRefreshFreq(uint8_t RefreshFreq)
{
  __innoCommandBuff__[0] = 104;
  __innoCommandBuff__[2] = RefreshFreq;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
uint8_t CompassB::GetRefreshStatus(void)
{
  __innoCommandBuff__[0] = 106;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0];
  return 0;  
}
uint8_t CompassB::GetDevAngleLimitStatus(void)
{
  __innoCommandBuff__[0] = 103;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
    return __innoCommandBuff__[0];
  return 0;  
}
void CompassB::Calibration(uint8_t Time)
{
  __innoCommandBuff__[0] = 121;  
  __innoCommandBuff__[2] = Time;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}	
void CompassB::GetXField(int16_t& Field)
{
  __innoCommandBuff__[0] = 88;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Field = *((int16_t *)&__innoCommandBuff__);   
  }	        
}
void CompassB::GetYField(int16_t& Field)
{
  __innoCommandBuff__[0] = 89;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Field = *((int16_t *)&__innoCommandBuff__);  
  }	        
}
void CompassB::GetDevAngleLimit(uint8_t& Angle)
{
  __innoCommandBuff__[0] = 98;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Angle = __innoCommandBuff__[0];
  }	        
}
void CompassB::GetRefreshFreq(uint8_t& Freq)
{
  __innoCommandBuff__[0] = 105;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Freq = __innoCommandBuff__[0];
  }	        
}
void CompassB::RestoreDefaultCalValue(void)
{        
  __innoCommandBuff__[0] = 125;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);
}
void CompassB::GetZField(int16_t& Field)
{
  __innoCommandBuff__[0] = 130;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
    Field = *((int16_t *)&__innoCommandBuff__);  
  }	        
}
void CompassB::GetDimension(uint8_t& Dim){
  __innoCommandBuff__[0] = 97;
  __innoNumByteToRead__ = 4;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Dim = __innoCommandBuff__[0];
  }	        
}
void CompassB::SetCurrentTargetAngle(void)
{       
  __innoCommandBuff__[0] = 133;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}
void CompassB::GetTargetAngle(uint16_t& Angle)
{
  __innoCommandBuff__[0] = 135;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Angle = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}

