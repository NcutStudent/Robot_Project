/**
  ******************************************************************************
  * @file 		MotoRunnerB
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "arm32f.h"
#include "I2CRoutines.h"
#include "BarometerA.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*----------------------command list------------------------------------------*/                                                                
/*----------------------------------------------------------------------------*/
BarometerA::BarometerA(uint8_t mySlaveID)
{
	SlaveID = mySlaveID;
    InitArmCommander();
}
void BarometerA::GetPressuremBar(float &PressuremBar)
{
  __innoCommandBuff__[0] = 88;
  __innoNumByteToRead__ = 5;  	  
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	PressuremBar = *((float *)&__innoCommandBuff__);
}
void BarometerA::GetAltitude10Feet(int32_t &Altritude)
{
  __innoCommandBuff__[0] = 152;              
  __innoNumByteToRead__ = 5;  	  
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  	Altritude = *((long *)&__innoCommandBuff__);
}
void BarometerA::SetSeaLevelPressure(uint16_t SeaLeveIPressure)
{
  __innoCommandBuff__[0] = 215;
  *((uint16_t *)&__innoCommandBuff__[2]) = SeaLeveIPressure;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);
}    
void BarometerA::SetMode(uint8_t Mode)
{
  __innoCommandBuff__[0] = 217;
  __innoCommandBuff__[2] = Mode;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);
}        						  

void BarometerA::GetAltitudeFeet(float &Altitude)
{
  __innoCommandBuff__[0] = 153;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Altitude = *((float *)&__innoCommandBuff__);   
  }	          
}
void BarometerA::SetRecordPressureCnt(uint16_t Cnt)
{       
  __innoCommandBuff__[0] = 170;
  *((uint16_t *)&__innoCommandBuff__[2]) = Cnt;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);    
}
void BarometerA::SetRecordAltitudeCnt(uint16_t Cnt)
{
  __innoCommandBuff__[0] = 171;
  *((uint16_t *)&__innoCommandBuff__[2]) = Cnt;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 6);    
}
void BarometerA::StartAutoPressureRecord(void)
{        
  __innoCommandBuff__[0] = 172;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);    
}
void BarometerA::StartAutoAltitudeRecord(void)
{
  __innoCommandBuff__[0] = 173;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 3);      
}
void BarometerA::StopAutoPressureRecord(void)
{
  __innoCommandBuff__[0] = 174;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  }	        
  
}
void BarometerA::StopAutoAltitudeRecord(void)
{
  __innoCommandBuff__[0] = 175;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
  }	        
 
}
void BarometerA::SaveCurPressure(uint8_t Num)
{    
  __innoCommandBuff__[0] = 176;
  __innoCommandBuff__[2] = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);    
}
void BarometerA::SaveCurAltitude(uint8_t Num)
{       
  __innoCommandBuff__[0] = 177;
  __innoCommandBuff__[2] = Num;
  __i2cWriteBuffer(__innoCommandBuff__, SlaveID, 5);    
}
void BarometerA::LoadPressure10mBar(uint8_t Num, uint16_t& Pressure)
{
  __innoCommandBuff__[0] = 178;
  __innoCommandBuff__[2] = Num;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Pressure = *((uint16_t *)&__innoCommandBuff__);   
  }	        
}
void BarometerA::LoadPressuremBar(uint8_t Num, float& Pressure)
{
  __innoCommandBuff__[0] = 179;
  __innoCommandBuff__[2] = Num;
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Pressure = *((float *)&__innoCommandBuff__); 
  }	          
}
void BarometerA::LoadAltitude10Feet(uint8_t Num, uint32_t& Altitude)
{
  __innoCommandBuff__[0] = 180;
  __innoCommandBuff__[2] = Num;    
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Altitude = *((uint32_t *)&__innoCommandBuff__); 
  }	          
}
void BarometerA::LoadAltitudeFeet(uint8_t Num, float& Altitude)
{
  __innoCommandBuff__[0] = 181;
  __innoCommandBuff__[2] = Num;    
  __innoNumByteToRead__ = 5;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 5, &__innoNumByteToRead__))
  {
	  Altitude = *((float *)&__innoCommandBuff__);   
  }	          
}
uint8_t BarometerA::GetPressureAlarmStatus(void)
{
  __innoCommandBuff__[0] = 202;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;   
}
uint8_t BarometerA::GetAltitudeAlarmStatus(void)
{
  __innoCommandBuff__[0] = 203;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;  
}
void BarometerA::GetRecordPressureCnt(uint16_t& Cnt)
{
  __innoCommandBuff__[0] = 206;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = *((uint16_t *)&__innoCommandBuff__); 
  }	        
}
void BarometerA::GetRecordAltitudeCnt(uint16_t& Cnt)
{
  __innoCommandBuff__[0] = 207;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Cnt = *((uint16_t *)&__innoCommandBuff__);   
  }	           
}
uint8_t BarometerA::GetRefreshStatus(void)
{
  __innoCommandBuff__[0] = 208;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  return __innoCommandBuff__[0];
  }	        
  return 0;   
}
void BarometerA::GetSeaLevelPressure(uint16_t& Pressure)
{
  __innoCommandBuff__[0] = 216;
  __innoNumByteToRead__ = 3;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Pressure = *((uint16_t *)&__innoCommandBuff__); 
  }	         
}
void BarometerA::GetMode(uint8_t& Mode)
{
  __innoCommandBuff__[0] = 218;
  __innoNumByteToRead__ = 2;
  if(!__i2cReadBuffer(__innoCommandBuff__, SlaveID, 3, &__innoNumByteToRead__))
  {
	  Mode = __innoCommandBuff__[0];
  }	           
} 

