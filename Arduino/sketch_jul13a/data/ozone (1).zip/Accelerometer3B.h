/**
  ******************************************************************************
  * @file 		Accelerometer3B
  * @author  	Innovati Team
  * @version  	V0.1.0
  * @date     	07/18/2011
  * @brief  	Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, Innovati SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 Innovati, Inc</center></h2>
  */
#ifndef __INNO_ACCELEROMETER3B
#define __INNO_ACCELEROMETER3B	 
#include "innotype.h"
class Accelerometer3B
{
    private:
	uint8_t SlaveID;
	public:
	Accelerometer3B(uint8_t);
	void GetXYZForce(int16_t&, int16_t&, int16_t&);
	void GetAngle2D(uint16_t&);
	void GetAngle3D(uint16_t&, uint8_t&);    
	void GetXADVal(uint16_t&);
	void GetYADVal(uint16_t&);
	void GetZADVal(uint16_t&);    
	void SetAngle2D(uint16_t);
	void GetDevAngle2D(int16_t&);
    void SetAngle3D(uint16_t, uint8_t);
    void GetDevAngle3D(int16_t&, char&);
    void GetDevAngle3D(int16_t&, int8_t&);
	void SetRefreshFreq(uint8_t);
	void SetAxis2D(uint8_t);     

	void GetXForce(int16_t&);
	void GetYForce(int16_t&);
	void GetZForce(int16_t&);
	void GetForce2D(int16_t&, int16_t&);
	void GetForce3D(int16_t&, int16_t&, int8_t&);
	void GetRefreshFreq(uint8_t&);
	void SetTimerFreq(uint16_t);
	void StartTimer(void);
	void StopTimer(void);
	uint8_t GetTimerStatus(void);
	void SetXForceLimit(uint8_t, uint16_t);
	void GetXForceLimit(uint8_t, uint16_t&);
	uint8_t GetXForceLimitStatus(void);
	void SetYForceLimit(uint8_t, uint16_t);
	void GetYForceLimit(uint8_t, uint16_t&);
	uint8_t GetYForceLimitStatus(void);
	void SetZForceLimit(uint8_t, uint16_t);
	void GetZForceLimit(uint8_t, uint16_t&);
	uint8_t GetZForceLimitStatus(void);
	void GetMaxXForce(int16_t&);
	void GetMaxYForce(int16_t&);
	void GetMaxZForce(int16_t&);
	void ClrMaxXForce(void);
	void ClrMaxYForce(void);
	void ClrMaxZForce(void);
	void SaveCalVal(uint8_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t, uint16_t);
	void LoadCalVal(uint8_t, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&, uint16_t&);
	void RestoreCalVal(void);
    
};
#endif



